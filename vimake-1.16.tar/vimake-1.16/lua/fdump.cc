// =====================================================================================
// 
//       Filename:  fdump.cc
// 
//    Description:  Methods for the fdump class 
// 
//          $Id: fdump.cc,v 1.1.1.1 2010/10/16 09:10:51 mike Exp $
//          $Revision: 1.1.1.1 $
// 
//         Author:  Mike Lear (motn), mikeofthenight2003@yahoo.com
//   Copyright (C) 2006-10 Mike Lear <mikeofthenight2003@yahoo.com>           
//                                                                            
//   This file is free software; as a special exception the author gives      
//   unlimited permission to copy and/or distribute it, with or without       
//   modifications, as long as this notice is preserved.                      
//                                                                            
//   This program is distributed in the hope that it will be useful, but      
//   WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//   implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// 
// =====================================================================================
//
#include "fdump.h"
namespace edn {



Fdump::Fdump(const string &str) throw (invalid_argument) {
	
                        struct stat sbuf;
                        mfileName = str;

                if ( stat( (mfileName).c_str(), &sbuf ) < 0 ) {
                        string error = "\n\tError: Unable to open file " + mfileName;
                        throw invalid_argument(error);
                        }
                        mSize = sbuf.st_size;
}



char* Fdump::setBuffer() throw (bad_alloc) {

                try {
                        buf = new  char [Bsize];
                    }   catch (bad_alloc &ml) {
                        cerr <<  "\n\tError: Unable to allocate sufficient memory ["
                             << ml.what() << "]" << endl;
                        exit (1);
                        }
return buf;
}



void  Fdump::dumpFile(int opt) throw(invalid_argument,runtime_error) {

                        ifstream fin;
						ifstream::pos_type size,bytesread,bytestoget;
                        fin .exceptions(std::ios_base::badbit | std::ios_base::failbit);

                        bytesread = 0;
                        fin.open( (mfileName).c_str(), ios_base::in|ios_base::binary|ios_base::ate );
                if(fin.fail()){
                        delete[] buf;
                        string error = "\n\tError: Unable to open file " + mfileName;
                        throw invalid_argument(error);
                        } 
						 
                        size = fin.tellg();                   
                        fin.seekg (0, ios_base::beg);       
                        bytesread = 0;                      

                if 	(size <= Bsize)         				// if filesize is less or equal to buffer size                
                        bytestoget = size;                  // bytes to get, equals the filesize
                else                                    	// otherwise
                        bytestoget = Bsize;                 // bytes to get, equals the  buffer size

                do {
                     try {
                        fin.seekg (bytesread, ios_base::beg);
                     } catch (ios_base::failure ml) {
                        delete[] buf;
                        string error = "\n\tError: A seek error occurred on file " + mfileName;
                        throw runtime_error(error);
                        } 
					 
                    try {
                         fin.read  (buf, bytestoget);
                    } catch (ios_base::failure ml) {
                        delete[] buf;
                        string error =  "\n\tError: A read error occurred in file " +  mfileName;
                        throw runtime_error(error);
                    }
                        display ((unsigned char*)buf,bytestoget, opt);
                        bytesread += bytestoget;           // total of bytes read and bytes to get

                 if ((bytesread + bytestoget) > size)      // if bytes read plus bytes to get is greater than filesize
                        bytestoget = size - bytesread;     // bytes to get, equals filesize minus bytes read. 

                 } while (bytestoget !=0 || fin.eof());
                        delete[] buf;
                        fin.close();

}

// NOTE: // ##
//
// There are 2 versions of the autosprintf format line: The shorter line simply prints a '.' if
// the control code character is less than ascii 33.
// The longer version also prints dots for any ascii char less than 33 and greater than ascii 127(del)
// You can replace the  current version in the the two "j loops" if you so wish.
//  cout << autosprintf("%c",(buf[j+i] >= 32 ? buf[j+i] : '.' ));                          // ## short version
//  cout << autosprintf("%c",(((buf[j+i] >= 32) && (buf[j+i] <= 126)) ? buf[j+i] : '.' )); // ## long version
//
void Fdump::display(unsigned char *buf,int bytestoget,int opt ) {
static unsigned int offset=0;

            switch (opt) {

            case 1:     for (int i = 0; i <= bytestoget; i += 16 ) {
                        cout  << autosprintf("\n%08X  %03o %03o %03o %03o  %03o %03o %03o %03o"
                                                   "  %03o %03o %03o %03o  %03o %03o %03o %03o   ",
                        offset,buf[i],buf[i+1],buf[i+2],buf[i+3],buf[i+4],buf[i+5],buf[i+6],buf[i+7],
                        buf[i+8],buf[i+9],buf[i+10],buf[i+11],buf[i+12],buf[i+13],buf[i+14],buf[i+15]);
                        for (int j = 0; j <= 15; j++ )
                        cout << autosprintf("%c",(((buf[j+i] >= 32) && (buf[j+i] <= 126)) ? buf[j+i] : '.' )); // ## long version
                        offset += 16;
                        }
                        break;

            case 2:     for (int i = 0; i <= bytestoget; i += 16 ) {
                        cout <<  autosprintf("\n%08X  %02x %02x %02x %02x  %02x %02x %02x %02x"
                                                   "  %02x %02x %02x %02x  %02x %02x %02x %02x  ",
                        offset,buf[i],buf[i+1],buf[i+2],buf[i+3],buf[i+4],buf[i+5],buf[i+6],buf[i+7],
                        buf[i+8],buf[i+9],buf[i+10],buf[i+11],buf[i+12],buf[i+13],buf[i+14],buf[i+15]);
                        for (int j = 0; j < 16; j++ )
                        cout << autosprintf("%c",(((buf[j+i] >= 32) && (buf[j+i] <= 126)) ? buf[j+i] : '.' )); // ## long version
                        offset += 16;
                        }
                        break;
            default:    break;
            }
                        cout << "\n\n\tFilesize is " << mSize << " bytes." << endl;

}

} // namespace ends

