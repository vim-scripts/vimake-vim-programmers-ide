#import <stdio.h>
#import <errno.h> 
#import <stdlib.h>

#define STDOUT 1
#define STDIN 0
extern char **environ;
char *path = NULL;

int main(int argc,char *argv[]) 
{

int i;

	printf("The environment list for %s is \n",argv[0]); 

	for (i = 0; environ[i] != NULL; i++)
		printf("env[%d]: %s\n",i,environ[i]);
		exit(0);
}
