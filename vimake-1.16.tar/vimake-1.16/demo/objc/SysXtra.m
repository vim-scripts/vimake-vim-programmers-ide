#import "SysInf.h"


@implementation SystemInfo

-(void) usingObjectC {

		pw = getpwuid(getuid());
		endpwent();

	if (uname(&myname) < 0) {
		fprintf(stderr,"Error obtaining system information\n");
	exit(1);
	}
	if ( (hptr = gethostbyname(myname.nodename)) == NULL) {
		fprintf(stderr,"Error obtaining system information\n");
		exit(1);
		}
		NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];

		NSString *Str1  = [NSString stringWithFormat: @"\n\tProcess id is               %ld", (long)getpid() ];
		NSString *Str2  = [NSString stringWithFormat: @"\n\tParent Process id:          %ld",(long)getppid() ];
  		NSString *Str3  = [NSString stringWithFormat: @"\n\tUser Name:                  %s",pw->pw_name ];
  		NSString *Str4  = [NSString stringWithFormat: @"\n\tOwner Group id:             %ld",(long)getgid() ];
  		NSString *Str5  = [NSString stringWithFormat: @"\n\tOwner User  id:             %ld",(long)getuid() ];
  		NSString *Str6  = [NSString stringWithFormat: @"\n\tUser Shell:                 %s",pw->pw_shell ];
		NSString *Str7  = [NSString stringWithFormat: @"\n\tHome Directory:             %s",pw->pw_dir ];
  		NSString *Str8  = [NSString stringWithFormat: @"\n\tFull Name:                  %s",pw->pw_gecos ];
		NSString *Str9  = [NSString stringWithFormat: @"\n\tHostname:                   %s", hptr->h_name ];

		printf( "%s", [Str1 cString] ); 	printf( "%s", [Str2 cString] ); 	printf( "%s", [Str3 cString] );
		printf( "%s", [Str4 cString] ); 	printf( "%s", [Str5 cString] ); 	printf( "%s", [Str6 cString] );
		printf( "%s", [Str7 cString] ); 	printf( "%s", [Str8 cString] ); 	printf( "%s", [Str9 cString] );
		
		[pool release];


	switch (hptr->h_addrtype) {
		case 	AF_INET: 	pptr = hptr->h_addr_list;
						for ( ; *pptr != NULL; pptr++)
							printf("\n\tIp Address:                 %s",
							inet_ntop(hptr->h_addrtype,*pptr,str,sizeof(str)));
						break;
		default:  			fprintf (stderr,"\tunknown address type");
						break;
						}

			for (pptr = hptr->h_aliases; *pptr != NULL; pptr++) 
					printf("\n\tAlias:                      %s", *pptr);
					printf("\n");

}
@end

