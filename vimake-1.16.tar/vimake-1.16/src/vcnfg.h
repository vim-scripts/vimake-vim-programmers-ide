#ifndef __VCNFG__H
#define __VCNFG__H
// =====================================================================================
//
//       Filename:  vcnfg.h
//
//    Description:  Header File for the Viconfig class
// 
//        $Id: vcnfg.h,v 1.2 2010/10/16 22:56:39 mike Exp $
//        $Revision: 1.2 $
// 
//         Author:  Mike Lear  mikeofthenight2003@yahoo.com
//   Copyright (C) 2006-9 Mike Lear <mikeofthenight2003@yahoo.com>           
//                                                                            
//   This file is free software; as a special exception the author gives      
//   unlimited permission to copy and/or distribute it, with or without       
//   modifications, as long as this notice is preserved.                      
//                                                                            
//   This program is distributed in the hope that it will be useful, but      
//   WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//   implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// 
// =====================================================================================
//
#include 	<iostream>
#include 	<string>
#include 	<signal.h>
#include 	<sys/wait.h>
#include 	<sys/stat.h>
#include 	<sstream>
#include 	<algorithm>
#include 	<fstream>
#include 	<memory>
#include 	<errno.h> // used in runcmd  handlers
#include 	<vector>
#include 	<map>
#include 	<fcntl.h>
#include 	<pwd.h>
#include 	"error.h"
#include 	"utils.h"


namespace   edn {

	using   std::cout;
	using   std::cerr;
	using   std::endl;
	using   std::ends;
	using   std::ifstream;
	using   std::istream;
	using   std::ofstream;
	using   std::ios;
	using   std::string;
	using   std::vector;
	using   std::istringstream;
	using   std::ostringstream;
	using   std::stringstream;

}



namespace edm{
extern bool isXterm;
using   namespace edn;



	class Viconfig : public virtual Utils {
			protected:
						std::string _Options;
						std::string _Libraries;
			public:
						Viconfig() {
						 	_Options    = "_options";
							_Libraries  = "_libraries";
						}
						virtual auto_ptr <string> GetViPath(const char* InFileName);
						virtual int			GetSetCfg(std::string& InFileName);
						virtual void 		MapToFile(std::string& InFileName); 
						Viconfig *operator->() { return this; }
						virtual ~Viconfig(){};
	};


} // namespace ends
#endif
