// =====================================================================================
// 
//       Filename:  viclean.cc
// 
//    Description:  Source code for the vimake package 
//
//          $Id: viclean.cc,v 1.4 2011/02/22 19:08:09 mike Exp $
//          $Revision: 1.4 $
// 
//          Author:  Mike Lear (motn), mikeofthenight2003@yahoo.com
//          Copyright (C) 2006-9 Mike Lear <mikeofthenight2003@yahoo.com>            
// 
//          This file is free software; as a special exception the author gives     
//          unlimited permission to copy and/or distribute it, with or without       
//          modifications, as long as this notice is preserved.                      
//
//          This program is distributed in the hope that it will be useful, but      
//          WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//          implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// =====================================================================================
//
#include "vclean.h"
bool	edm::isXterm;
using 	namespace edn;
using 	namespace edm;




int main(int argc,char *argv[]){
Error<string> E;	

			try {

				auto_ptr <string> tty (new string(getenv("TERM")));
				*tty  == "xterm" ? isXterm = true : isXterm = false;

			if (argc != 2) throw BadFileArgs();
                const auto_ptr < string > FileName (new string (argv[argc - 1]));
				Vclean C(*FileName);
				C->Validity (FileName -> c_str());

			if(!(getuid())) E->Quit("Viclean must not be run as root!\n\n");
				*tty = C->Getenv("PWD")->c_str();
				string::size_type idx =
				tty->find("bin");

			if (idx != string::npos) {
				E->Quit("Viclean will not work in a /bin subdirectory!\n\n");
				}

			E->Warn("You are about to remove all executable and object files\n\t\t  from:"
				,tty->c_str(),"\n\t\t  Do you wish to continue? <y/n> ");
				char choice;
				std::cin >> choice;
				choice = tolower(choice);
				C->DisplayObj(choice);

			} catch (const FileError& e) {
				E->Mesg(e.what(),"\n");
				exit (1);
			} catch ( ... ) {
				E->Quit("unrecognized exception!");
			}


return 0;
}

