// =====================================================================================
// 
//       Filename:  vimake.cc
// 
//    Description:  Source code for the multi language vim-gvim make program 
//
//        $Id: vimake.cc,v 1.9 2011/02/22 19:08:09 mike Exp $
//        $Revision: 1.9 $ [lua added]
// 
//         	Author:  Mike Lear (motn), mikeofthenight2003@yahoo.com
//	 		Copyright (C) 2006-10 Mike Lear <mikeofthenight2003@yahoo.com>            
// 
//	 		This file is free software; as a special exception the author gives     
//	 		unlimited permission to copy and/or distribute it, with or without       
//	 		modifications, as long as this notice is preserved.                      
//
//	 		This program is distributed in the hope that it will be useful, but      
//	 		WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//	 		implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// =====================================================================================
#include "vmake.h"
using 	namespace edn;
using 	namespace edm;
bool 	edm::isXterm;


int main(int argc,char *argv[]){
Error<string> E;	


		try {

				auto_ptr <string> CmdLine (new string(getenv("TERM")));
                *CmdLine  == "xterm" ? isXterm = true : isXterm = false;

			if (argc != 2) throw BadFileArgs();
				const auto_ptr < string > FileName (new string (argv[argc - 1]));
				Vkeys K(*FileName);
				unsigned Index = K->Validity(FileName -> c_str());	
				CmdLine -> clear();  										
				CmdLine = K.ReadBuildConfig ("cmdline.arg");  			
				bitset<Keys> FunKeys (string(CmdLine->c_str()));

			if (*FileName == MainFile) {
			   	E->Mesg("\tYou are about to build using ",MainFile);
			   	/// E->Mesg("You are about to build using ",MainFile,"\n");
		   		CmdLine = K->NewName(FileName -> c_str());
				Index = K->Validity(CmdLine -> c_str());	
			if (Index == 1)
				Vkeys K(*CmdLine);
				K->SetProgName(*CmdLine);
			if (FunKeys.test(F3)) { 	
	   			std::getline(cin,*CmdLine); // flush stream
				}	
			}


			if (FunKeys.test(F3)) { 	
					CmdLine -> clear();

			if ((FunKeys.test(F7)) && (!FunKeys.test(F8))) {	
					;

			} else {


					E->Mesg("Enter build<make> files: ");
					std::getline(cin,*CmdLine);

		   			}
					CmdLine =  K.Lastargs(*CmdLine);

			} else {
					CmdLine -> clear(); 							
					}

			switch (Index) {
				case 1:
				case 2:
				case 3: if (CmdLine -> size() > 0) {
							K->BuildMainFile(*CmdLine);
							break;
						} else {	
							K->BuildMainFile(); 
							break;
						}
				case 6: 	K->BuildLuaBin(*CmdLine);  
							break;
				default: break;
				}

			} catch (const FileError& e) {
				E->Mesg(e.what(),"\n");
				exit (1);
			} catch ( ... ) {
				E->Quit("Unrecognized exception\n");
				}


return 0;
} 
