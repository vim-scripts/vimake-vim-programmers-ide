#ifndef __VIRUN__H
#define __VIRUN__H
// =====================================================================================
// 
//       Filename:  vclean.h
// 
//    Description:  Header File for the vimake package
// 
//         $Id: vclean.h,v 1.5 2011/02/22 19:08:08 mike Exp $
//         $Revision: 1.5 $
// 
//         Author:  Mike Lear  mikeofthenight2003@yahoo.com
//   Copyright (C) 2006-9 Mike Lear <mikeofthenight2003@yahoo.com>           
//                                                                            
//   This file is free software; as a special exception the author gives      
//   unlimited permission to copy and/or distribute it, with or without       
//   modifications, as long as this notice is preserved.                      
//                                                                            
//   This program is distributed in the hope that it will be useful, but      
//   WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//   implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// 
// =====================================================================================
//
//
#include 	<iostream>
#include 	<fstream>
#include 	<sstream>
#include 	<string>
#include 	<list>
#include 	<algorithm>
#include 	<sys/stat.h>
#include 	<vector>
#include	<cstdlib>
#include 	<dirent.h>
#include 	<sys/termios.h>
#ifndef 	TIOCGWINSZ
#include 	<sys/ioctl.h>
#endif
#include  	"utils.h"

namespace   edn {
using   std::cout;
using   std::cerr;
using   std::endl;
using   std::ends;
using   std::ifstream;
using   std::ofstream;
using   std::ios;
using   std::string;
using   std::list;
using   std::vector;
using   std::istringstream;
using   std::ostringstream;
using   std::stringstream;
}

namespace edm{
using namespace edn;


	class Vclean : public virtual Utils {  
		protected:
			std::string     _MainFileSrc;
			std::string     _MainFileObj;
			std::string     _MainFileExe;
			std::string     _CmdLine;
		public:
			Vclean(std::string &str);
			virtual int Validity(const std::string& InFileName);
			virtual ~Vclean() {};
			virtual void DisplayObj(char c);
			Vclean *operator->() { return this; }
	};
}
#endif

