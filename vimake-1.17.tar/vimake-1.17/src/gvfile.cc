//======================================================================================
//   
//          Filename:  gvfile.cc
//       Description:  Source code for the gvim vimake program 
//
//           $Id: gvfile.cc,v 1.2 2011/03/11 21:44:04 mike Exp $
//           $Revision: 1.2 $
//
//   Copyright (C) 2006-11 Mike Lear <mikeofthenight2003@yahoo.com>            
//                                                                            
//   This file is free software; as a special exception the author gives      
//   unlimited permission to copy and/or distribute it, with or without       
//   modifications, as long as this notice is preserved.                      
//                                                                            
//   This program is distributed in the hope that it will be useful, but      
//   WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//   implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//   
//======================================================================================
#include "gvifile.h"
using   namespace edn;
using   namespace edm;

bool    edm::isXterm;


int  main(int argc,char *argv[]) {
Error <string>E;
ostringstream os;

		try {
				if  (argc != 3) throw BadFileArgs();
                    const auto_ptr < string > FileName (new string (argv[argc - 1]));
                    const auto_ptr < string > Debugger (new string (argv[argc - 2]));
					
					auto_ptr<string> CmdLine(new string);
					auto_ptr<string> CmdFile(new string);

					Gvidbug G(*FileName);
					G->Validity(*FileName);
					string Ident(*Debugger);
	    			string::size_type idx; 
					Ident[0] == 'g' ? idx = 1 : idx = 0;
					CmdLine = G->CheckDbPath(Debugger->c_str()); // CmdLine = /usr/bin/gdb
					CmdFile = G->GetExeFile(FileName->c_str());  // CmdFile = vimake

				switch(idx) {
					case 0:	os << *CmdLine << " " << *CmdFile << endl;  
							break;
					case 1: os << *CmdLine << " -q " << *CmdFile << endl; 
							break;
					default: throw BadFileArgs();
							break;
					}
				    G->Runcmd(os.str());

			} catch (out_of_range& e){
					E->Quit(e.what(),"\n");
			} catch (const FileError& e) {
					E->Mesg(e.what());
			} catch ( ... ) {
					E->Quit("Unrecognized exception");
					}

return 0;
}

