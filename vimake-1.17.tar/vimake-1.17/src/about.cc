#include <iostream>

int main(){
std::cout << "\n\tVimake-1.17 is written using the GNU g++ compiler. Vimake started life as a bunch of sed scripts\n" <<
		     "\twhich allowed me to compile C and Nasm programs, it progressed to perl, but I found I was forever\n" <<
			"\tloading modules when ever I had a linux upgrade or new version of Perl. I next used the C language\n" <<
			"\tbut it was difficult to control memory leakage. I finally settled on C++ simply because of the STL\n" <<
			"\tlibrary. Vimake was written and tested in my spare time usually during the winter months.\n" <<
			"\tNOTE:  vilink.pl  is the last remaining perl script to survive." << std::endl << std::endl;
	
	std::cout << "\t\tCopyright (C) 2006-11 Mike Lear <mikeofthenight2003@yahoo.com>\n\n" <<            
			"\t\tThis file is free software; as a special exception the author gives\n" <<     
			"\t\tunlimited permission to copy and/or distribute it, with or without\n" <<       
			"\t\tmodifications, as long as this notice is preserved.\n\n" <<                      
			"\t\tThis program is distributed in the hope that it will be useful, but\n" <<      
			"\t\tWITHOUT ANY WARRANTY, to the extent permitted by law; without even the\n" <<   
			"\t\timplied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE." << std::endl << std::endl; 
			 
return 0;
}
	

