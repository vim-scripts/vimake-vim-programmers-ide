#ifndef __TEMP__H__
#define __TEMP__H__
//--------------------------------------------------------------------------------------
//
//		$Id: temp.hpp,v 1.2 2010/11/17 20:03:24 mike Exp $
//		Author: Mike Lear mikeofthenight2003@yahoo.com
//
//		TEMP HEADER:   Display messages - variables whilst testing source code
//		and
//		SHOWIT:		   Display any stl container class
//
// 		Usage:     Showit("\nInformation message\n",container.begin(),container.end());
//
//		Example: 	Showit("Vector contains\n",vec.begin(),vec.end());
//
//		or
//					Showit("List Message",list.begin(),list.end());
//
//		This will display the contents of the container at any place in the file.			
//
//--------------------------------------------------------------------------------------
//
//		NOTE: 
//		This header uses macros which should not be left in the finished program.
//		Remove this header and any macros used once testing is completed.
//
//		Usage:    
//		Place this header file in your include path, then include the temp header in
//		your source code:
//		IE: 
//			#include <iostream>
//			#include <string>
//			#include <temp.hpp>
//
//		You can then place SV(var); or DV(var,var); anywhere in your code to display
//		variables,messages etc  during testing.
//
//		SV(var); 		-- Displays the file then line number and a Single Variable
//		DV(var,var);  	-- Displays the file then line number and two (Dual Variables)
//
//      Example Output 
//		vmake.cc:  line no: 225:   count = 0
//      vmake.cc:  line no: 230:   FunKey.test(F7) = 0,  FunKey.test(F8) = 1
//      vmake.cc:  line no: 231:   count = 1
//--------------------------------------------------------------------------------------

#ifndef _GLIBCXX_ITERATOR
#include <iterator>
#endif
#ifndef _GLIBCXX_STRING
#include <string>
#endif

#ifndef _GLIBCXX_IOSTREAM
#include <iostream>
#endif

template <typename T>  // display contents of stl container uses input iteraror
    void Showit(const std::string& msg,T start, T end){
    T itr;
    std::cerr << msg.c_str() << std::endl;
    for (itr = start; itr != end; ++itr)
        std::cerr << *itr << " ";
        std::cerr << std::endl;
}


#define SV(m)   std::cerr << std::dec <<  __FILE__ << ":  line no: " << __LINE__  \
				<< ":   " << #m " = "  << m << std::endl;
#define DV(m,l) std::cerr << std::dec <<  __FILE__ << ":  line no: " << __LINE__  \
				<< ":   " << #m " = "  << m << ",  " << #l " = " << l << std::endl;


#endif
