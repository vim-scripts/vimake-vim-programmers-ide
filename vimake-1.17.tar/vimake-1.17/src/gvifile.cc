// =====================================================================================
// 
//       Filename:  gvifile.cc
// 
//    Description:  Source code for the (gvim) Vimake (debugger package)
// 
//        $Id: gvifile.cc,v 1.2 2011/03/11 21:44:03 mike Exp $
//        $Revision: 1.2 $
// 
//         Author:  Mike Lear , mikeofthenight2003@yahoo.com
//	                                                                          
//	 	Copyright (C) 2006-11  Mike Lear <mikeofthenight2003@yahoo.com>            
//	                                                                          
//	 	This file is free software; as a special exception the author gives      
//	 	unlimited permission to copy and/or distribute it, with or without      
//	 	modifications, as long as this notice is preserved.                      
//	                                                                          
//	 	This program is distributed in the hope that it will be useful, but      
//	 	WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//	 	implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
//	                                                                         
// =====================================================================================
#include "gvifile.h"
#include <temp.hpp>
namespace   edm {
using       namespace edn;



// =====================================================================================
//       Class:  	VIDBUG
//      Method:  	CONSTRUCTOR
// =====================================================================================
Gvidbug::Gvidbug(std::string &InMainFileName) {   
struct stat statbuf;
std::string::size_type idx;      	
std::string FileNameExt;				 


			_DisplayMode  = 0;
			_MainFileSrc = InMainFileName;
			_MainFileObj  = InMainFileName;
			_MainFileExe  = InMainFileName;
			idx = InMainFileName.rfind('.');

		if (idx == std::string::npos) { 
			throw FileIndexError(InMainFileName.c_str());

		} else {		

			FileNameExt.assign(_MainFileSrc,idx,_MainFileSrc.size());   
			_MainFileExe.erase (idx, FileNameExt.size ());		 
			_MainFileObj.replace(idx,FileNameExt.size(),".o");   
			}

		if (stat(_MainFileSrc.c_str(),&statbuf)<0){
			throw FileStatError(InMainFileName.c_str());
			}

}

// =====================================================================================
//       Class:  VIDBUG
//      Method:  VALIDITY
// Description:  Determine suitablity of the file type for use with debuggers.
// 		  NOTE:  File type with an index of five are included to allow the F12
// 		  		 key to be used with DDD for the bashdb and perldb debuggers.
// 		  		 This program only controls C/C++ AT&T and NASM assembler
// 		  		 debuggers.
// =====================================================================================
int Gvidbug::Validity(const std::string& InFileName){
std::string FileExtent,FileName;
std::string::size_type index;


			FileName = InFileName; 
			index    = FileName.rfind('.');
			FileExtent.assign(FileName,++index,FileName.size());
			index    = GetFileExt(FileExtent);


		if ((index < 1) || (index > 5)) {
			throw FileUnknownError(FileName.c_str());
			}


return index;
}

auto_ptr<string> Gvidbug::CheckDbPath(const std::string &InFileName) {

std::string FileName;
			
		auto_ptr<string> Result(new string);
			FileName = InFileName; 
			Result =  Getenvpath(FileName.c_str());
	    if (FileName.size() > 0) {
			 return Result;
		 } else {

			return Result;
		 }
}		


auto_ptr<string> Gvidbug::GetExeFile(const std::string &InFileName) {
	auto_ptr<string>Temp(new string);
	string      FileExtent;
	string      FileName;
	string		InFile = InFileName;
	string::size_type Index;

			FileName = InFileName;
			Index    = FileName.rfind('.');
			FileExtent.assign(FileName,++Index,FileName.size());
			Index    = GetFileExt(FileExtent);

		switch (Index) {
			case 1:
			case 2:
			case 3: *Temp = _MainFileExe;
					break;
			case 4: if (FileExtent == "rb") {
						*Temp = InFile.insert(0," -rdebug ");
						break;
					} else 
					if (FileExtent == "pl" || FileExtent == "pm") {
						*Temp = InFile.insert(0," -d ");
						break;
					} else
						*Temp = InFileName;
					break;
			default: break;
			}

return Temp;
}

} // namespace edm
