#include <Foundation/Foundation.h>
#include <AppKit/AppKit.h>

/* See the Tutorial in the doc directory for build instructions.
 *
 * VimakeDemo is an app demonstration using Vimake. It is not a
 * completed program, just the framework to build a help system
 * for Vimake. I have included it to show that Vimake can build
 * an run an application given the right parameters. 
 * The Resources directory and contents were created separately
 * using Gimp to create the icon and Vim for the property list
 * file. 
 * Again NOTE this file is only for demonstration purposes.
 */



int main (int argc, const char **argv)
{ 
	NSAutoreleasePool *pool;
	NSApplication *app;
	NSMenu *mainMenu;
	NSMenu *menu;
	NSMenuItem *menuItem;

	pool = [NSAutoreleasePool new];
    app = [NSApplication sharedApplication];
   
  

   // Main Menu
   mainMenu = AUTORELEASE ([NSMenu new]);
   [mainMenu addItemWithTitle: @"Info..."
         action: @selector (orderFrontStandardInfoPanel:)
         keyEquivalent: @""];
   // Submenu
   menuItem = [mainMenu addItemWithTitle: @"Help"
            action: NULL
            keyEquivalent: @""];
   menu = AUTORELEASE ([NSMenu new]);
 	[mainMenu setSubmenu: menu forItem: menuItem];
  	[menu addItemWithTitle:@"F1..." action:@selector(F1Help:)keyEquivalent:@""];
   	[menu addItemWithTitle:@"F2..." action:@selector(F2Help:)keyEquivalent:@""];
	[menu addItemWithTitle:@"F3..." action:@selector(F3Help:)keyEquivalent:@""];
	[menu addItemWithTitle:@"F4..." action:@selector(F4Help:)keyEquivalent:@""];
	[menu addItemWithTitle:@"F5..." action:@selector(F5Help:)keyEquivalent:@""];
	[menu addItemWithTitle:@"F6..." action:@selector(F6Help:)keyEquivalent:@""];
	[menu addItemWithTitle:@"F7..." action:@selector(F7Help:)keyEquivalent:@""];
	[menu addItemWithTitle:@"F8..." action:@selector(F8Help:)keyEquivalent:@""];
	[menu addItemWithTitle:@"F9..." action:@selector(F9Help:)keyEquivalent:@""];
	[menu addItemWithTitle:@"F10..." action:@selector(F10Help:)keyEquivalent:@""];
	[menu addItemWithTitle:@"F11..." action:@selector(F11Help:)keyEquivalent:@""];
	[menu addItemWithTitle:@"F12..." action:@selector(F12Help:)keyEquivalent:@""];
	[menu addItemWithTitle:@"CtlUpArrow" action:@selector(CupHelp:)keyEquivalent:@""];
	[menu addItemWithTitle:@"CtlDnArrow" action:@selector(CtlDnHelp:)keyEquivalent:@""];
	[menu addItemWithTitle:@"CtlRtArrow" action:@selector(CtlRtHelp:)keyEquivalent:@""];
	[menu addItemWithTitle:@"CtlLtArrow" action:@selector(CtlLtHelp:)keyEquivalent:@""]; 
	[menu addItemWithTitle:@"Hide" action:@selector(hide:)keyEquivalent:@""];
	[mainMenu addItemWithTitle:@"Hide" action:@selector(hide:)keyEquivalent:@""];
	[mainMenu addItemWithTitle:@"Quit" action:@selector(terminate:)keyEquivalent:@"q"];
	[app setMainMenu: mainMenu];
	[mainMenu setTitle: @"ViMake"]; 

	[app run];
	[[NSUserDefaults standardUserDefaults] synchronize];



return NSApplicationMain (argc, argv);
}

