#ifndef __SYS_INFO_H__      
#define __SYS_INFO_H__      

#import <Foundation/NSObject.h>
#import <Foundation/NSString.h>
#import <Foundation/NSAutoreleasePool.h>
#import <stdio.h>
#import <stdlib.h>
#import <unistd.h>
#import <pwd.h>
#import <errno.h>
#import <sys/sysinfo.h>
#import <sys/types.h>
#import <sys/utsname.h>
#import <sys/shm.h>
#import <sys/ipc.h>
#import <arpa/inet.h>
#import <netdb.h>

#include <time.h>   // import gives time warnings!


#define 	ARRAY_SIZE 	40000
#define 	MEM_SIZE   	100000
#define 	SHM_SIZE   	100000
#define 	SHM_MODE   	0600
#define 	IP_ADDR	   	16

int 	status, shmid, now, days;
int  	hours, minutes, seconds;
char 	*shmptr, array[ARRAY_SIZE];
char    *ptr, **pptr,  str[IP_ADDR];

struct 		passwd     *pw;
struct 		hostent    *hptr;
struct 		utsname    myname;
struct 		sysinfo    info;
struct 		tm         *tm_time;
time_t 		currentTime;

@interface SysInformation: NSObject
-(void) usingVimake;
@end

@interface SystemInfo: NSObject
-(void) usingObjectC;
@end

#endif
