#ifndef __GVIDBG__H
#define __DVIDBG__H
// =====================================================================================
// 
//       Filename:  gvfile.h
// 
//    Description:  Header File for the Gvim debug mode for vimake
// 
//       $Id: gvifile.h,v 1.3 2011/03/11 21:47:28 mike Exp $
//       $Revision: 1.3 $
// 
//	 Copyright (C) 2006-11 Mike Lear <mikeofthenight2003@yahoo.com>              
//	                                                                          
//	 This file is free software; as a special exception the author gives      
//	 unlimited permission to copy and/or distribute it, with or without       
//	 modifications, as long as this notice is preserved.                      
//	                                                                          
//	 This program is distributed in the hope that it will be useful, but      
//	 WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//	 implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// 
// =====================================================================================


#include 	<map>
#include 	<pwd.h>
#include    <iostream>
#include    <fstream>
#include    <sstream>
#include    <string>
#include 	<algorithm>
#include    <sys/stat.h>
#include    <vector>
#include    <stdexcept>
#include    "utils.h"
#include    "error.h"


namespace   edn {

	using   std::cout;
	using   std::cerr;
	using   std::endl;
	using   std::ends;
	using   std::ifstream;
	using   std::ofstream;
	using   std::ios;
	using   std::string;
	using   std::vector;
	using   std::istringstream;
	using   std::ostringstream;
	using   std::stringstream;
	using	std::out_of_range;

}



namespace edm{
extern bool isXterm;
using namespace edn;	



	class Gvidbug : public virtual Utils {  
		protected:
			std::string 	_MainFileSrc;   	
			std::string 	_MainFileObj;   
			std::string 	_MainFileExe;	 	
		public:
			Gvidbug(std::string &str);
			virtual int Validity(const std::string& InFileName);
			virtual auto_ptr <std::string> CheckDbPath(const std::string &InFilename);
			virtual auto_ptr<string> GetExeFile(const std::string& InFileName);
			Gvidbug *operator->() { return this; }
			virtual ~Gvidbug() {};
	};


}  // edm namespace
#endif

