// =====================================================================================
// 

//       Filename:  vhelp.cc
// 
//    Description:  Display the hot keys used in the vim-gvim vimmake program 
//
//          $Id: vhelp.cc,v 1.3 2010/11/04 12:30:08 mike Exp $
//          $Revision: 1.3 $
// 
//          Author:  Mike Lear (motn), mikeofthenight2003@yahoo.com
//          Copyright (C) 2006-10 Mike Lear <mikeofthenight2003@yahoo.com>            
// 
//          This file is free software; as a special exception the author gives     
//          unlimited permission to copy and/or distribute it, with or without       
//          modifications, as long as this notice is preserved.                      
//
//          This program is distributed in the hope that it will be useful, but      
//          WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//          implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// =====================================================================================
//
#include "vmake.h"
using   namespace edn;
using   namespace edm;
bool    edm::isXterm;




int main(int argc,char *argv[]){
Error <string>E;


		try {

			auto_ptr <string> CmdLine (new string(getenv("TERM")));
			*CmdLine  == "xterm" ? isXterm = true : isXterm = false;

		if (argc != 2) throw BadFileArgs();
			const auto_ptr < string > FileName (new string (argv[argc - 1]));
			Vkeys M(*FileName);
			M -> Validity (*FileName);
			ostringstream ostr;

	isXterm == true ? ostr  <<  WoB  <<  "  VIMAKE FUNCTION HOTKEYS  " << Off << endl :
       			      ostr  <<  nTab <<  "  VIMAKE FUNCTION HOTKEYS  " <<  endl;

	if (isXterm) {
			ostr << Blue << "<F1>"   << Off  << Tab2 << "Return back from a Quickfix window.";
			ostr << Blue << "<F2>"   << Off  << Tab2 << "Quit does NOT save the current file. File contents unchanged.";
			ostr << Blue << "<F3>"   << Off  << Tab2 << "F3 OFF Single File Build."
								     << nTab << Tab2 << "F3 ON  Multi File Build.";
			ostr << Blue << "<F4>"   << Off  << Tab2 << "Open a Quickfix window.";
			ostr << Blue << "<F5>"   << Off  << Tab2 << "Step down through errors in a Quickfix window.";
			ostr << Blue << "<F6>"   << Off  << Tab2 << "Step back through errors in a Quickfix window.";
			ostr << Blue << "<F7>"   << Off  << Tab2 << "Close the Quickfix window.";
			ostr << Blue << "<F8>"   << Off  << Tab2 << "F8 OFF (Default) Normal Build Takes Place"
									 << nTab << Tab2 << "F8 OFF (Default) Debug Mode GDBINIT"
									 << nTab << Tab2 << "F8 ON  (Examine) Display Build Options"
									 << nTab << Tab2 << "F8 ON  (Switch)  Debug Mode to INTELTYPE";
			ostr << Blue << "<F9>"   << Off  << Tab2 << "Save(write) current edit to file.";
			ostr << Blue << "<F10>"  << Off  << Tab2 << "F3 OFF F8 OFF  Single File Build"
								     << nTab << Tab2 << "F3 ON  F8 OFF  Multiple File Build"
									 << nTab << Tab2 << "F3 OFF F8 ON   Display Single File Build"
									 << nTab << Tab2 << "F3 ON  F8 ON   Display Multiple File Build";
			ostr << Blue << "<F11>"  << Off  << Tab2 << "F3 OFF Run Program Directly (No Command Line Args)"
									 << nTab << Tab2 << "F3 ON  Run Program With Command Line Arguments";
			ostr << Blue << "<F12>"  << Off  << Tab2 << "F8 OFF (gdb c/c++)Debug Global Gdbinit File Selected"
                                     << nTab << Tab2 << "F8 ON  (gdb nasm)Debug Global Inteltype File Selected"
                                     << nTab << Tab2 << "F8 key Swaps mode between INTELTYPE and GDBINIT";
			ostr << Blue << "<Ctrl+Up>"   << Off  <<  "\tSelect build(make) options. For the current File";
			ostr << Blue << "<Ctrl+Down>" << Off  <<  "\tVimake function key menu";

			ostr << Blue << "<Ctrl+Left>" << Off  <<  "\tAuto Assembly Linker Selection:"
									 << nTab << Tab2 << "<Ctrl+Left> ON  Load linker selected automatically."
									 << nTab << Tab2 << "<Ctrl+Left> OFF Linker selected by <Ctrl+Up> keys.";
			ostr << Blue << "<Ctrl+Right>" << Off <<  "\tClean the Current Project Directory:"
									 << nTab << Tab2 << "Removes all object and executable files from the current"
									 << nTab << Tab2 << "working directory. Similar in action to a [make clean]";
		} else {
			ostr << nTab << "<F1>"   << Tab2 << "Return back from a Quickfix window.";
			ostr << nTab << "<F2>"   << Tab2 << "Quit does NOT save the current file. File contents unchanged.";
			ostr << nTab << "<F3>"   << Tab2 << "F3 OFF Single File Build."
									 << nTab << Tab2 << "F3 ON  Multi File Build.";
			ostr << nTab << "<F4>"   << Tab2 << "Open a Quickfix window.";
			ostr << nTab << "<F5>"   << Tab2 << "Step down through errors in a Quickfix window.";
			ostr << nTab << "<F6>"   << Tab2 << "Step back through errors in a Quickfix window.";
			ostr << nTab << "<F7>"   << Tab2 << "Close the Quickfix window.";
			ostr << nTab << "<F8>"   << Tab2 << "F8 OFF (Default) Normal Build Takes Place"
									 << nTab << Tab2 << "F8 OFF (Default) Debug Mode GDBINIT"
									 << nTab << Tab2 << "F8 ON (Examine)  Display Build Options"
									 << nTab << Tab2 << "F8 ON (Switch.)  Debug Mode to INTELTYPE";
			ostr << nTab << "<F9>"   << Tab2 << "Save(write) current edit to file.";
			ostr << nTab << "<F10>"  << Tab2 << "F3 OFF F8 OFF  Single File Build"
									 << nTab << Tab2 << "F3 ON  F8 OFF  Multiple File Build"
									 << nTab << Tab2 << "F3 OFF F8 ON   Display Single File Build"
									 << nTab << Tab2 << "F3 ON  F8 ON   Display Multiple File Build";
			ostr << nTab << "<F11>"  << Tab2 << "F3 OFF Run Program Directly (No Command Line Args)"
									 << nTab << Tab2 << "F3 ON  Run Program With Command Line Arguments";
			ostr << nTab << "<F12>"  << Tab2 << "F8 OFF (gdb c/c++)Debug Global Gdbinit File Selected"
									 << nTab << Tab2 << "F8 ON  (gdb nasm)Debug Global Inteltype File Selected";
			ostr << nTab << "<Ctrl+Up>"   <<  "\tSelect build(make) options. For the current File";
			ostr << nTab << "<Ctrl+Down>" <<  "\tVimake function key menu";
			ostr << nTab << "<Ctrl+Left>" <<  "\tAuto assembly linker selection"
									 << nTab << Tab2 << "<Ctrl+Left> ON  Load linker selected automatically."
									 << nTab << Tab2 << "<Ctrl+Left> OFF Linker selected by <Ctrl+Up> keys.";
			ostr << nTab << "<Ctrl+Right>" <<  "\tClean the current project directory."
									 << nTab << Tab2 << "Removes all object and executable files from the current"
									 << nTab << Tab2 << "working directory. Similar in action to a [make clean]";
			} 
			cout <<  ostr.str() << endl;
			
		} catch (const FileError& e) {
			E->Mesg(e.what());
		} catch ( ... ) {
			E->Quit("unrecognized exception");
			}

return(0);
}
