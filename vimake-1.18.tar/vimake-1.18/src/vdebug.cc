// =====================================================================================
// 
//       Filename:  vdebug.cc
// 
//    Description:  Source code for the Vimake (debugger package)
// 
//        $Id: vdebug.cc,v 1.10 2011/03/12 22:02:35 mike Exp $
//        $Revision: 1.10 $
// 
//         Author:  Mike Lear , mikeofthenight2003@yahoo.com
//	                                                                          
//	 	Copyright (C) 2006-9 Mike Lear <mikeofthenight2003@yahoo.com>            
//	                                                                          
//	 	This file is free software; as a special exception the author gives      
//	 	unlimited permission to copy and/or distribute it, with or without      
//	 	modifications, as long as this notice is preserved.                      
//	                                                                          
//	 	This program is distributed in the hope that it will be useful, but      
//	 	WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//	 	implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
//	                                                                         
// =====================================================================================
#include "vdebug.h"
namespace   edm {
using       namespace edn;



// =====================================================================================
//       Class:  	VIDBUG
//      Method:  	CONSTRUCTOR
// =====================================================================================
Vidbug::Vidbug(std::string &InMainFileName) {   
struct stat statbuf;
std::string::size_type idx;      	
std::string FileNameExt;				 


			_DisplayMode  = 0;
			_MainFileSrc = InMainFileName;
			_MainFileObj  = InMainFileName;
			_MainFileExe  = InMainFileName;
			idx = InMainFileName.rfind('.');

		if (idx == std::string::npos) { 
			throw FileIndexError(InMainFileName.c_str());

		} else {		

			FileNameExt.assign(_MainFileSrc,idx,_MainFileSrc.size());   
			_MainFileExe.erase (idx, FileNameExt.size ());		 
			_MainFileObj.replace(idx,FileNameExt.size(),".o");   
			}

		if (stat(_MainFileSrc.c_str(),&statbuf)<0){
			throw FileStatError(InMainFileName.c_str());
			}

}

// =====================================================================================
//       Class:  VIDBUG
//      Method:  VALIDITY
// Description:  Determine suitablity of the file type for use with debuggers.
// 		  NOTE:  File type with an index of five are included to allow the F12
// 		  		 key to be used with DDD for the bashdb and perldb debuggers.
// 		  		 This program only controls C/C++ AT&T and NASM assembler
// 		  		 debuggers.
// =====================================================================================
int Vidbug::Validity(const std::string& InFileName){
std::string FileExtent,FileName;
std::string::size_type index;


			FileName = InFileName; 
			index    = FileName.rfind('.');
			FileExtent.assign(FileName,++index,FileName.size());
			index    = GetFileExt(FileExtent);


		if ((index < 1) || (index > 5)) {
			throw FileUnknownError(FileName.c_str());
			}


return index;
}

// =====================================================================================
// 		 Class:	Vidbug
// 	    Method:	ChangeMainName ( objc only)
// 	    User has option to create a different executable file name rather than
// 	    use the default name of main.
// =====================================================================================
void  Vidbug::ChangeMainName(const string &InFileName) {
	// change source and exe file if main.m name has been copied
              _MainFileSrc = InFileName;
              _MainFileExe = _MainFileSrc;
              _MainFileExe.erase(_MainFileExe.size()-2,_MainFileExe.size());
}


// =====================================================================================
// 		 Class:	Vidbug
// 	    Method:	GetDbFile
// Description:	Select the correct filetype for the debugger called with the F12 key.
// =====================================================================================
int Vidbug::GetDbFile(const string &DbgExt) {
map<const string,unsigned int> FileExt;


        FileExt["c"  ]  = 1;     FileExt["c++" ] = 1;
        FileExt["CPP"]  = 1;     FileExt["cpp" ] = 1;
        FileExt["C"  ]  = 1;     FileExt["cc"  ] = 1;
        FileExt["cp" ]  = 1;     FileExt["cxx" ] = 1;
        FileExt["s"  ]  = 1;     FileExt["S"   ] = 1;
        FileExt["asm"]  = 1;     FileExt["pl"  ] = 5;
		FileExt["py" ]  = 3;	 FileExt["rb"  ] = 4;
        FileExt["sh" ]  = 2;     FileExt["bash"] = 2;
        FileExt["m" ]  = 1;    


        if (FileExt.find(DbgExt) != FileExt.end()) {
            return FileExt[DbgExt];
			} else {
		return 0;
		}
return 0;
}


// =====================================================================================
// 		 Class:	Vidbug
// 	    Method:	SelectDbg
// Description:	Select the correct debugger, prevents F12 key selecting debuggers which
//           	do not work with some scripting languages.
//     Example:
//           	Ald debugger called with ruby script will fail
// =====================================================================================
int Vidbug::SelectDbg(const string &Debugger) {
map<const string,unsigned int> DbgType;

			/*
			Option 1 works only with compiled or assembled programs ie c/c++ asm
			Option 2 works with option 1 and certain script languages
			Option 3 - 6 work with specific script languages
			*/

        DbgType["ald"    ]  = 1;     DbgType["gdb"   ] = 1;   
        DbgType["gdbtui" ]  = 1;     DbgType["kdbg"  ] = 1;
        DbgType["insight"]  = 1;     DbgType["ddd"   ] = 2; 
        DbgType["pydb"   ]  = 3;     DbgType["bashdb"] = 4;
        DbgType["rdebug" ]  = 5;     DbgType["perl"  ] = 6;
		DbgType["nemiver"]  = 1;     DbgType["ruby"  ] = 5;

        if (DbgType.find(Debugger) != DbgType.end()) {
            return DbgType[Debugger];
        } else {
            return 0;
            }
}


// =====================================================================================
//       Class:  VIDBUG
//		Method:	 SWITCHDBG
// Description:  Determines if the debugger selected will work with the source program  
// 				 under debug. For example the gdb debugger will not debug a scripting
// 				 language such as perl or python. Whereas the front end ddd will call
// 				 pydb or perl -d to allow scripting languages to be debugged and will
// 				 also call ald or gdb to allow assembly or c/c++ code to be debugged.
// =====================================================================================
int Vidbug::SwitchDbg(const string &Debugger,const string &SrcExt,const string &SrcFile) {
std::vector<std::string>Dvec(7);
std::string::size_type idx;
struct stat StatBuf;
string CmdLine;

			std::ostringstream 	 os;
			Dvec[ExtentFile]   = SrcExt;
			Dvec[SrcDbgFile]   = SrcFile;
			Dvec[ExeDbgFile]   = _MainFileExe;
			Dvec[MDebugger]    =  Debugger;   
			int mDbugIndex 	   = SelectDbg(Dvec[MDebugger]);
			int mFileIndex 	   = GetDbFile(Dvec[ExtentFile]);
			Dvec[MDebugger][0] == 'g' ?  idx = 1 : idx = 0;
            Dvec[DbgInitIntel] = Dvec[DbgInitAtt] = Dvec[DbgInitTAtt] = *Getenv("HOME");

			(Dvec[DbgInitIntel]) += "/etc/inteltype";
             Dvec[DbgInitAtt]    += "/etc/gdbinit";
             Dvec[DbgInitTAtt]   += "/etc/gdbtinit";

		if (stat(Dvec[DbgInitIntel].c_str(),&StatBuf)<0)
			throw FileStatError(Dvec[DbgInitIntel].c_str());

		if (stat(Dvec[DbgInitAtt].c_str(),&StatBuf)<0)
			throw FileStatError(Dvec[DbgInitAtt].c_str());

		if (stat(Dvec[DbgInitTAtt].c_str(),&StatBuf)<0)
			throw FileStatError(Dvec[DbgInitTAtt].c_str());

			CmdLine = *ReadBuildConfig("cmdline.arg");
			bitset<Keys> FunKey (string(CmdLine.c_str()));

		if (Debugger.compare(0,6,"gdbtui") == 0) {
           Dvec[DbgInitAtt].swap(Dvec[DbgInitTAtt]);
           }

		if (FunKey.test(F8)) {
			Dvec[DbgInitAtt].swap(Dvec[DbgInitIntel]);
			}
		 cout << nTab << "Global configuration file: " << Dvec[DbgInitAtt].c_str() << " selected\n";

			//-----------------------------------------------------------------------
			//	Dual switch:
			//	checks and sets debugger selected by F12 key with source code
			//	If the debugger is not suitable reports that and quits
			//	otherwise sets any options needed to load and debug file
			//-----------------------------------------------------------------------


		switch (mDbugIndex) {
		case 1:   switch(mFileIndex) {	// ald gdb insight kdbg		
					  
	  				case 1: if (idx) {  
							os  << Dvec[MDebugger] << " -q -x " << Dvec[DbgInitAtt] 
								<< " " << Dvec[ExeDbgFile] << endl;
							} else { 	
							os << Dvec[MDebugger] << " " << Dvec[ExeDbgFile] << endl; 
							}
							mDbugIndex=mFileIndex=0;
							break;

					case 2:	; case 3: ; case 4: ;	case 5: 
							throw out_of_range("debugger selected is invalid with this file!");
							break;	
					default: 	
							break;
					}

		case 2:   switch(mFileIndex) { //ddd

					case 1: os << Dvec[MDebugger] << " " << Dvec[ExeDbgFile] << endl; 
							mDbugIndex=mFileIndex=0;
							break;

			  		case 2:	Dvec[MDebugger].append(" --debugger bashdb ");
							os << Dvec[MDebugger] << " " << Dvec[SrcDbgFile] << endl;
							mDbugIndex=mFileIndex=0;
							break;

	  				case 3:	Dvec[MDebugger].append(" --debugger pydb ");
							os << Dvec[MDebugger] << " " << Dvec[SrcDbgFile] << endl;
							mDbugIndex=mFileIndex=0;
							break;

	  				case 4:	throw out_of_range("ddd is invalid with ruby!");
							break;

	  				case 5:	Dvec[MDebugger].append(" --debugger perl -d ");
							os << Dvec[MDebugger] << " " << Dvec[SrcDbgFile] << endl;
							mDbugIndex=mFileIndex=0;
					default: 	
							break;	  
					}

		case 3:   switch(mFileIndex) { // pydb

					case 1: ; case 2:	
							throw out_of_range("pydb is invalid with this file!");
							break;

					case 3:	os << Dvec[MDebugger] << " " << Dvec[SrcDbgFile] << endl;
							mDbugIndex=mFileIndex=0;
							break;

					case 4:	;  case 5:
							throw out_of_range("pydb is invalid with this file!");

		  			default:
							break;	  
					}

		case 4:   switch(mFileIndex) { // bashdb

					case 1: throw out_of_range("bashdb is invalid with this file!");
							break;

					case 2:	os << Dvec[MDebugger] << " " << Dvec[SrcDbgFile] << endl;
							mDbugIndex=mFileIndex=0;
							break;

					case 3:	; case 4: ; case 5:
							throw out_of_range("bashdb is invalid with this file!");

	  				default: 	
							break;	  
					}

		case 5:   switch(mFileIndex) {  // ruby

					case 1: ; case 2: ; case 3:	
							throw out_of_range("ruby-rdebug is invalid with this file!");
							break;

					case 4:	if (Dvec[MDebugger].compare(0,4,"ruby") == 0) { // ruby or rdebug
							Dvec[MDebugger].append(" -rdebug ");
							}
							os << Dvec[MDebugger] << " " << Dvec[SrcDbgFile] << endl;
							mDbugIndex=mFileIndex=0;
							break;

					case 5:	throw out_of_range("ruby-rdebug is invalid with this file!");
							break;
	  				default: 	
							break;	  
					}
		case 6:   switch(mFileIndex) {  // perl

					case 1: ; case 2: ; case 3:	; case 4:
							throw out_of_range("perl is invalid with this file!");
							break;

					case 5:	Dvec[MDebugger].append(" -d ");
							os << Dvec[MDebugger] << " " << Dvec[SrcDbgFile] << endl;
							mDbugIndex=mFileIndex=0;
							break;

	  				default:
							break;	  
					}
		  		default: 
				  			break;	  
			}

		
					if (Runcmd(os.str().c_str())<0) {
						throw RunTimeError(os.str());
						}

return (0);
}


// =====================================================================================
//       Class:  VIDBUG
//      Method:  DEBUGFILE
// Description:  Selects the designated debugger from a list of debuggers types situated
// 				 at $HOME/etc/debuggers. The function also selects the correct type of 
// 				 global debugger configuration file(usually .gdbinit) to suit either 
// 				 C/C++ AT&T or for the Nasm debugger (inteltype) configuration. This is 
// 				 achieved by use of the <F8> key during a <F12 Debug session>
// =====================================================================================
int	 Vidbug::DebugFile(const std::string& InDbugType){

struct stat StatBuf;
std::vector<std::string>Dvec(7);
std::string::size_type index;
std::string CmdLine;


			Dvec[SrcDbgFile] = _MainFileSrc;
			Dvec[ExeDbgFile] = _MainFileExe;
			Dvec[MDebugger]  =  InDbugType;   

			index = Dvec[SrcDbgFile].rfind('.');
			Dvec[ExtentFile].assign(Dvec[SrcDbgFile],
					index,Dvec[SrcDbgFile].size());
			index = GetFileExt(Dvec[ExtentFile]);
			Dvec[ExtentFile].erase(0,1);  
			std::ostringstream os;
 		 	Dvec[DbgInitAtt] = Dvec[DbgInitTAtt] = Dvec[DbgInitIntel] = *Getenv("HOME");

		if (InDbugType.compare(0,6,"gdbtui") == 0) {  // select either gdbtui init file
			(Dvec[DbgInitTAtt]) += "/etc/gdbtinit"; 
		} else 
		if (InDbugType.compare(0,3,"gdb") == 0) {     // or gdb init file
			(Dvec[DbgInitAtt]) += "/etc/gdbinit"; 
			}

		if (stat(Dvec[DbgInitAtt].c_str(),&StatBuf)<0)
			throw FileStatError(Dvec[DbgInitAtt].c_str());
			(Dvec[DbgInitIntel]) += "/etc/inteltype";

		if (stat(Dvec[DbgInitIntel].c_str(),&StatBuf)<0)
			throw FileStatError(Dvec[DbgInitIntel].c_str());
		 	CmdLine = *ReadBuildConfig("cmdline.arg");
			bitset<Keys> FunKey (string(CmdLine.c_str()));

		if (FunKey.test(F8)) { 
			Dvec[DbgInitAtt].swap(Dvec[DbgInitIntel]);	
			}
			index = Dvec[SrcDbgFile].rfind('.');

		if (index == std::string::npos) {   // look for a script type file
			throw FileIndexError(Dvec[SrcDbgFile].c_str());
			}

			Dvec[ExtentFile].assign(Dvec[SrcDbgFile],
					++index,Dvec[SrcDbgFile].size());
			SwitchDbg(Dvec[MDebugger],Dvec[ExtentFile],Dvec[SrcDbgFile]);


		
return 0; 			
}


// =====================================================================================
//       Class:  VIDBUG
//      Method:  READDEBUGGERS
// Description:  Open's the file $HOME/etc/debuggers from which a type of debugger or
// 				 Front end like Kdbg or DDD may be selected. This selection is then used
// 				 as the current debugger. If the list is empty (No debuggers listed) then
// 				 the menu is skipped and the default debugger usually Gdb is loaded.
// =====================================================================================
auto_ptr < std::string > Vidbug::ReadDebuggers(const std::string& InFileName){

			//---------------------------------------------------------------------------
			// 		Build path to /home/user/etc/debuggers 	 
			//		Open and read list of available debuggers and front ends.
			//---------------------------------------------------------------------------
			auto_ptr <string> LocalFileName (new string(InFileName));
 		 	auto_ptr <string> TempString (Getenv("HOME"));
			TempString -> append("/etc/");
			LocalFileName -> insert(0,*TempString);
			std::ifstream fin(LocalFileName -> c_str());   

		if (fin.fail())	throw FileOpenError(InFileName.c_str());
			
	 		std::vector < std::string > dbvec;
	typedef istream_iterator< std::string > str_input;
			copy(str_input(fin),str_input(),back_inserter(dbvec));

		if (!fin.eof()){
			fin.close();
			throw FileReadError(InFileName.c_str());
			}

			TempString -> clear();
			std::vector<std::string>::iterator itr;

		for (itr=dbvec.begin();itr!=dbvec.end();++itr)
			*TempString += *itr + " "; 
			std::istringstream ist(*TempString);

			//--------------------------------------------------------------------------
			//		Return a space separated list of debuggers in FileTmpBuffer
			//---------------------------------------------------------------------------
			auto_ptr <string> FileTmpBuffer (new string);

		while (ist >> *TempString) {
			Getenvpath(TempString -> c_str());
			*FileTmpBuffer += *TempString + " ";
			}

		fin.close();

			// If only 1 filename in debuggers  remove any surrounding whitespace
			string::size_type  nospaces = FileTmpBuffer->find_first_not_of(" \t\n");
			FileTmpBuffer->erase(0,nospaces); // trim leading whitespace
			nospaces = FileTmpBuffer->find_last_not_of(" \t\n"); 
			FileTmpBuffer->erase(nospaces+1); // trim trailing whitespace

return FileTmpBuffer;  
}

} // namespace edm
