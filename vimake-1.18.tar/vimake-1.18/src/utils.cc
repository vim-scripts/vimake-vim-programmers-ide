// =====================================================================================
// 
//       Filename:  utils.cc
// 
//    Description:  Utility Class for the Vim - Gvim Multi Lanuage Build Project.
// 
//          $Id: utils.cc,v 1.15 2011/03/19 14:51:35 mike Exp $
//          $Revision: 1.15 $
// 
//         	Author:  Mike Lear , mikeofthenight2003@yahoo.com
//	 		Copyright (C) 2006-10 Mike Lear <mikeofthenight2003@yahoo.com>            
//	                                                                          
//	 		This file is free software; as a special exception the author gives      
//	 		unlimited permission to copy and/or distribute it, with or without       
//	 		modifications, as long as this notice is preserved.                      
//	                                                                          
//	 		This program is distributed in the hope that it will be useful, but      
//	 		WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//	 		implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
//	                                                                          
// =====================================================================================
#include "utils.h"
//--------------------------------------------------------------------------------------
extern char **environ;
namespace edm {
using namespace edn;

void Utils::ResetBit() {
auto_ptr <string> status (new string(*ReadBuildConfig("cmdline.arg")));

		bitset<Keys>  FunKey (string(status->c_str()));
		FunKey.reset(F4);
		status -> clear();
		status -> append(FunKey.to_string());
		UpdateCmdLine (*status);
}

//--------------------------------------------------------------------------------------
//       Class:  UTILS
//      Method:  CHECKFOREXECUTABLE (objective C only)
//      If a "main.m" file has been built with vimake using a new executable
//      name.  First find out the name of the new "xxxx.m" file, then if
//      found return it to method "ChangeMainName" before running program.
//--------------------------------------------------------------------------------------
auto_ptr < string > Utils::CheckForExecutable (const string& InFileName) {
Error<string> E;
struct stat statbuf;
struct utimbuf timebuf;
struct dirent *direntp;
DIR *dp;
vector  <string> List;
vector  <long> mTime;
vector  <long>::iterator tm;
vector  <string>::iterator itr;
std::map<long,string> mFile;
std::map<long,string>::iterator mf;

				string::size_type index;
				auto_ptr<string> origName (new string(InFileName.c_str()));
				if ((dp = opendir(".")) == NULL)           // run in the current working directory
				   	throw FileDirError();
			while ((direntp = readdir(dp)) != NULL) {

				if (direntp->d_ino == 0)            // skip over removed files (inode = 0)
					continue;

				if (stat(direntp->d_name,&statbuf) <0) {
					E->Mesg("Cannot get information on",direntp->d_name,"\n");
						                    }
                    *origName = direntp->d_name;
		 			index = origName -> find(".m");
				if (index != string::npos) {
					List.insert(List.end(),*origName);
					}
		 			index = origName -> find(".cc");
				if (index != string::npos) {
					List.insert(List.end(),*origName);
					}

			}
			closedir(dp);
			for (itr = List.begin(); itr != List.end(); ++itr){
			stat(itr->c_str(),&statbuf); 		
			timebuf.modtime = statbuf.st_mtime;

			mTime.insert(mTime.end(),timebuf.modtime);
			mFile[timebuf.modtime] = *itr;
        
			}
			tm =  max_element(mTime.begin(),mTime.end());
			if (mFile.find(*tm) != mFile.end())  // get latest main filename.m
				*origName = mFile[*tm];  // as it might be a new name entered.
			if (*origName == MainSwapFile)
				origName -> clear();  // don't want to rename the swap file

return  origName;
}

//--------------------------------------------------------------------------------------
//       Class:  UTILS
//      Method:  FILECOPY ( Source file to Desination file )
//--------------------------------------------------------------------------------------
//
void Utils::FileCopy(const string &InFileName,const string &OutFileName) {
int from_fd,to_fd;
int readbytes,writebytes;
const int BLKSZ = 1024;
char buf[BLKSZ];
char *cp;
        if((from_fd = open(InFileName.c_str(),O_RDONLY))== -1) {
            cerr << "\n\t-- Unable to open file -- " << InFileName.c_str();
            return;
            }
        if((to_fd = open(OutFileName.c_str(),O_WRONLY|O_CREAT|O_TRUNC,S_IRUSR|S_IWUSR))== -1) {
            cerr << "\n\t-- Cannot create file  -- " << OutFileName.c_str();
            return;
            }
        while((readbytes = read(from_fd,buf,BLKSZ))) {
        if((readbytes == -1) && (errno != EINTR))
            break;
        else if(readbytes > 0) {
            cp = buf;
        while((writebytes = write(to_fd,cp,readbytes))){
        if((writebytes == -1) && (errno != EINTR))
            break;
        else if(writebytes == readbytes)
            break;
        else if (writebytes > 0) {
            cp += writebytes;
            readbytes -= writebytes;
            }
        }
        if(writebytes == -1)
                break;
            }
        }
        close(from_fd);
		close(to_fd);

return;
}



//--------------------------------------------------------------------------------------
//       Class:  UTILS
//      Method:  VALIDITY ( Check for a valid filetype for building)
// Description:  Checks that the filename entered has a valid filename extension
// 				 and is of a suitable file type for building.
// 				 Index of 1,2,3,6 are valid for objc lua,c,c++,gas(as) and nasm source files
// 				 all other filetypes are rejected.
//--------------------------------------------------------------------------------------
int Utils::Validity(const string& InFileName) {
	
string FileExtent;
string FileName;
string::size_type index;
		
			FileName = InFileName;
			index = FileName.rfind('.');
			FileExtent.assign(FileName,++index,FileName.size());
			index = GetFileExt(FileExtent);
		switch (index) {
			case 1:			// return only known file extension types.
			case 2:			// throw an error for all others.
			case 3: 
			case 6: 	break;		
		   default: 	ResetBit();
						throw FileUnknownError(FileName.c_str());
					 	break;
						}	 

return index;
}


//--------------------------------------------------------------------------------------
//       Class:  UTILS
//      Method:  UpdateCmdLine
// Description:  Update the status flags of the function keys. 
// 		 Input:	 Updated status line for the 12 function keys
// 		Output:  returned input string
//--------------------------------------------------------------------------------------
auto_ptr < string > Utils::UpdateCmdLine (const string& InCmdArgs) {
			auto_ptr<string> CmdLine (new string(InCmdArgs));  // Cmdline = new funkey data

			auto_ptr<string> FileName (Getenv("HOME"));
			FileName -> append ("/etc/cmdline.arg");       // FileName = home/mike/etc/cmdline.arg

			ofstream fout;

 			fout.open(FileName->c_str());

		if (fout.fail()) {
			ResetBit();
			throw FileWriteError(FileName->c_str());
			}

			fout  << *CmdLine << endl;
			fout << "This file is generated by vitogl for the vimake package." << endl;
			fout << "Please DO NOT EDIT....!" << endl;
			fout.close();

		if (fout.fail()) {
			ResetBit();
			throw FileWriteError(FileName->c_str());
			}

return CmdLine;
}

//--------------------------------------------------------------------------------------
//       Class:  UTILS
//      Method:  READBUILDCONFIG
// Description:  Read the first line from the build options files which is placed at
// 				 $HOME/etc.  Each type of build consists of pair of files that
// 				 contain compile and link options. Each pair of files are identified
// 				 by the file extension currently being built. So that if a c++ build
// 				 is taking place then the files cc_options and cc_libraries would be
// 				 used. In a similar manner if a nasm program is called the the files
// 				 concerned would be asm_options and asm_libraries. Each pair of files
// 				 contain compile and link library options placed in them by the user. 
// 		Returns: The command line from the file opened. 
// 				 
//--------------------------------------------------------------------------------------
auto_ptr < string > Utils::ReadBuildConfig (const string& InFileName) {
			auto_ptr<string> LocalFileName (new string(InFileName));

			auto_ptr<string> TempString   (Getenv("HOME"));
			TempString -> append ("/etc/");
			LocalFileName->insert(0,*TempString);
			TempString -> clear();

			ifstream fin(LocalFileName->c_str(),ios::in);

		if (fin.fail()) {
			ResetBit();
			throw FileOpenError(InFileName.c_str());
			}
			
  while (true) {          // ignore hash # comments and newlines


	    if ( (fin.peek() == '#') || (fin.peek() == '\n')) {
		  	getline(fin, *TempString, '\n');
			TempString -> clear();
			continue;
			}

		if (!fin) break;
			getline(fin, *TempString, '\n'); // Obtain only first valid line in file
			break;
			}

		if (!fin.eof() && (fin.fail()||fin.bad())) {
			fin.clear();
			fin.close();
			}

		if (fin.eof()) {
			fin.clear();
			fin.close();
			}

		if (!fin.good()) {
			ResetBit();
			throw FileReadError(LocalFileName->c_str());
			}

return TempString;
}



//--------------------------------------------------------------------------------------
//       Class:  UTILS
//      Method:  STRSTRI (Search for word in a text file ignore case)
// Description:  The word to search for is first transfomed to lower case. 
// 				 The file is first copied as a series of words into a vector of strings. 
// 				 It is then translated to lowercase, sorted, a binary search finally
// 				 returns bool true or false.
//--------------------------------------------------------------------------------------
char toLower(char ch){
	return tolower(ch); 
}
string &ToLower(string &st) {
	transform(st.begin(),st.end(),st.begin(),toLower);
return st;
}
bool Utils::Strstri(const string &InFileName,const string &SrchFileName) {
vector<string>::iterator itr;
typedef istream_iterator<string> str_input;
vector<string> vec;
vector<int>::const_iterator it;

			auto_ptr<string> word (new string(SrchFileName));
			transform(word->begin(),word->end(),word->begin(),tolower);
			ifstream fin(InFileName.c_str());

		if (fin.fail()) {
			ResetBit();
			throw FileOpenError(InFileName.c_str());
			}

			copy(str_input(fin),str_input(),back_inserter(vec));
			transform(vec.begin(),vec.end(),vec.begin(),ToLower);
			sort(vec.begin(),vec.end());

		if (!fin.eof()) {
			fin.close();
			ResetBit();
			throw FileReadError(InFileName.c_str());
		}
			fin.close();
			bool Find_Word = false;
			Find_Word = binary_search(vec.begin(),vec.end(),*word);

return Find_Word;
}


//--------------------------------------------------------------------------------------
//       Class:  UTILS
//      Method:  STRSTR [ version for autolink] (
//      				Search for certain words in assembly source file.
//      Returns:		A long value containing the number of bits set by
//                      words found.
//      NOTE: 	If you search an assembly source  file for the start label
//      		such as "_start" it will find it. If the file contains the
//      		word main (perhaps commented out" it will also find that.
//      		This will cause the auto linker to fail as it will see two
//      		different labels. So alway remove any unwanted labels from
//      		the file.
//--------------------------------------------------------------------------------------
//
long  Utils::Strstr(const string &InFile) {
vector<string>::iterator itr;
typedef istream_iterator<string> str_input;
vector<string> vec;

			bitset<Link> LinkOpt = 0x0;

			ifstream fin(InFile.c_str());

		if (fin.fail()) {
			ResetBit();
			throw FileOpenError(InFile.c_str());
			}

			copy(str_input(fin),str_input(),back_inserter(vec));
			sort(vec.begin(),vec.end());

		if (!fin.eof()) {
			fin.close();
			ResetBit();
			throw FileReadError(InFile.c_str());
		}
					fin.close();
					bool Find_Word = false;
					Find_Word = 
					binary_search(vec.begin(),vec.end(),"_start");

			if (Find_Word) LinkOpt.set(L1);
					Find_Word = 
					binary_search(vec.begin(),vec.end(),"main:");

			if (Find_Word) LinkOpt.set(L2);
					Find_Word = 
					binary_search(vec.begin(),vec.end(),"printf");

			if (Find_Word) LinkOpt.set(L3);
					Find_Word = 
					binary_search(vec.begin(),vec.end(),"mov");

			if (Find_Word) LinkOpt.set(L4);
					Find_Word = 
					binary_search(vec.begin(),vec.end(),"movl");

			if (Find_Word) LinkOpt.set(L5);
					Find_Word = 
					binary_search(vec.begin(),vec.end(),"@function");

			if (Find_Word) LinkOpt.set(L6);


return  LinkOpt.to_ulong();
}

//--------------------------------------------------------------------------------------
//       Class:  UTILS
//      Method:  STRSTR (Search for word in a text file)
// Description:  Search for a given word in a file. The file is first copied as a series
// 				 of words into a vector of strings.  It is then sorted, a binary search 
// 				 returns bool true or false.
//--------------------------------------------------------------------------------------
bool Utils::Strstr(const string &InFileName,const string &SrchFileName) {
vector<string>::iterator itr;
typedef istream_iterator<string> str_input;
vector<string> vec;
string word;


			word = SrchFileName;
			ifstream fin(InFileName.c_str());

		if (fin.fail()) {
			ResetBit();
			throw FileOpenError(InFileName.c_str());
			}

			copy(str_input(fin),str_input(),back_inserter(vec));
			sort(vec.begin(),vec.end());

		if (!fin.eof()) {
			fin.close();
			ResetBit();
			throw FileReadError(InFileName.c_str());
		}
			fin.close();
			bool Find_Word = false;
			Find_Word = binary_search(vec.begin(),vec.end(),word);

return Find_Word;
}


//--------------------------------------------------------------------------------------
//  Get vimake version 
//--------------------------------------------------------------------------------------

int Utils::get_version() {
	
	string::iterator it;
   	int status = 0;

	auto_ptr<string> tempstr (new string( (char*)getenv("HOME")));
	auto_ptr<string> cmdline (new string("/etc/cmdline.arg"));
	auto_ptr <string> TempFile (new string (_Version.substr(2,9)));

		it = find ((*TempFile).begin(), (*TempFile).end(),109);
		*it -= 32; it++;  *it += 8;  it+=4; 
		*it -= 42; it+=2; *it -= 17; it++; --(*it);
		_Version.insert(33,*TempFile);
		cmdline -> insert (0, *tempstr);

	for (it = _Version.begin(); it != _Version.end(); ++it)
		status += *it;
		_Length = _Version.size();
		_FileLen = status;
	
        auto_ptr < string > mname  (new string);
        mname = ReadBuildConfig ("cmdline.arg");
        bitset<Keys>  FunKey (string(mname->c_str()));
 
    if ((status == 0xfe2) && (FunKey.test(F4) != true) ) {
        FunKey.set(F4);
        FunKey.reset(F9);
    } else {
        FunKey.set(F9);
        FunKey.reset(F4);
        _Length = 0;
        }
        mname -> clear();
        mname -> append(FunKey.to_string());
		UpdateCmdLine (*mname);

return status;
}	

//--------------------------------------------------------------------------------------
//       Class:  UTILS
//      Method:  GETFILEXT ( Map a files extension) 
// Description:  Search a map for a valid filename extension. 
// 		 Input:  The ".ext" of the filename  to check
// 		Output:  Returns a positive integer if found.
// 				 or 0 if not in the map.
//--------------------------------------------------------------------------------------
int Utils::GetFileExt(const string &Extension) {
map<const string,unsigned int> FileExtent;


		FileExtent["c"  ]  = 1;		FileExtent["c++" ] = 2;
		FileExtent["CPP"]  = 2;		FileExtent["cpp" ] = 2;
		FileExtent["C"  ]  = 2; 	FileExtent["cc"  ] = 2;
		FileExtent["cp" ]  = 2; 	FileExtent["cxx" ] = 2;
		FileExtent["s"  ]  = 3;		FileExtent["S"   ] = 3;
		FileExtent["asm"]  = 3; 	FileExtent["h"   ] = 5;
		FileExtent["H"  ]  = 5; 	FileExtent["hh"  ] = 5;
		FileExtent["inc"]  = 6; 	FileExtent["mac" ] = 6;
		FileExtent["pl" ]  = 4; 	FileExtent["py"  ] = 4;
		FileExtent["pm" ]  = 4; 	FileExtent["rb"  ] = 4;
		FileExtent["sh" ]  = 4; 	FileExtent["bash"] = 4;
		FileExtent["lua"]  = 6;    	FileExtent["bin" ] = 6;
		FileExtent["hpp"]  = 5;    	FileExtent["prj" ] = 2; 
		FileExtent["o"  ]  = 7;     FileExtent["m"   ] = 1; 

		if (FileExtent.find(Extension) != FileExtent.end()) {
			return FileExtent[Extension];
		} else {
			return 0;
			}
}


//--------------------------------------------------------------------------------------
//       Class:  UTILS
//      Method:  SREPLACE
// Description:  Search and replace a substring within a string.
// 		 Input:	 String to be searched,old sub string to remove,new substring to insert 	 
// 	   Returns:	 Bool true if search was successful. 
// 	   			 Bool false if search failed.
//--------------------------------------------------------------------------------------
bool Utils::Sreplace(string &str,const string &orig,const string &newstr) {
string::size_type idx;

			idx = str.find(orig);

		if (idx != string::npos) {
			str.replace(idx,orig.size(),newstr);
			return true;
			}
			return false;
}



//--------------------------------------------------------------------------------------
//       Class:  UTILS
//      Method:  GETENV
// Description:  auto_pointer string version of the "C" getenv function, 
// 				 The returned strings in the environment list are of the form NAME=VALUE
// 				 This function throws an exception if the environment NAME is not found.
//--------------------------------------------------------------------------------------
auto_ptr<string> Utils::Getenv(const string &name) {	
		auto_ptr<string>  envbuf(new string);
		auto_ptr<unsigned> count(new unsigned);
		auto_ptr<unsigned>   len(new unsigned);

			*len = name.length();
		for (*count = 0; environ[*count] != NULL; ++*count) {

		if ((name.compare(0,*len,environ[*count],0,*len) == 0) &&
            (environ[*count][*len] == '=')) {
            *envbuf += &environ[*count][*len+1];
			return(envbuf); 
			}
		} ResetBit();
		throw FilePathError(name.c_str());
}


//--------------------------------------------------------------------------------------
//       Class:  UTILS
//      Method:  GETENVPATH
// Description:  This appends the input filename to the end of each path and
// 				 returns the path if found. If filename is not in any environment
// 				 path an exception is thrown. This normally occurs if you attempt
// 				 to run a file that has not yet been compiled or the file is non existant
// 				 or is not in the environment path of the user.
//--------------------------------------------------------------------------------------
auto_ptr<string> Utils::Getenvpath(const string &fname) {	
struct stat statbuf;
auto_ptr < string > path(Getenv("PATH"));

         if (path -> empty()) {
			 ResetBit();
			throw FilePathError(fname.c_str());
            }

		while (Sreplace(*path,":","/ "));
			istringstream instr(*path);

        while (instr >> *path) {
            path->append(fname);
        if (stat(path->c_str(),&statbuf)<0) {
			continue;
		} else {
			return(path);
			break;
			}
		} ResetBit();
		throw FileStatError(fname.c_str());
}


//--------------------------------------------------------------------------------------
//       Class:  UTILS
//      Method:  RUNCMD
// 		Description:  Executes a command in a child process.
// 		This function with some slight modifications is derived from:
// 		"ADVANCED PROGRAMMING IN THE UNIX ENVIRONMENT" by
//		Richard Stevens and Stephen A Rago.
//--------------------------------------------------------------------------------------
int Utils::Runcmd(const std::string& cmd) {
Error<string> E;	
auto_ptr < string > Shell(new string);
			std::auto_ptr<pid_t>   childpid(new pid_t);
			int       status = 0;
			struct    sigaction SaveInt,SaveQuit,Ignore;
			sigset_t  ChildMask,SaveMask;
			Shell =   Getenvpath("bash");		
            Ignore.sa_handler = SIG_IGN;
            sigemptyset(&Ignore.sa_mask);
            Ignore.sa_flags = 0;

        if (sigaction(SIGINT,&Ignore,&SaveInt)<0) {
			E->Quit("SIGINT Handler failed!\n");
            }
        if (sigaction(SIGQUIT,&Ignore,&SaveQuit)<0) {
			E->Quit("SIGQUIT handler failed!\n");
            }
            sigemptyset(&ChildMask);
            sigaddset(&ChildMask,SIGCHLD);

        if (sigprocmask(SIG_BLOCK,&ChildMask,&SaveMask)<0) {
			E->Quit("SIGNALMASK failed!\n");
            }

        if ((*childpid = fork())<0) {
            E->Quit("Fork or childpid failed!\n");
        } else if (*childpid == 0) {
            sigaction(SIGINT, &SaveInt, NULL);
            sigaction(SIGQUIT,&SaveQuit,NULL);
            sigprocmask(SIG_SETMASK,&SaveMask,NULL);
			
		//----------------------------------------------------------------------------	
		//			Child executes the command line string
		//----------------------------------------------------------------------------	
         execl(Shell->c_str(),Shell->c_str(),"-c",cmd.c_str(),(char *)0);
		 throw RunTimeError("Exec failed in Runcmd function!");
		
        } else {
        while (waitpid(*childpid,&status,0)<0)
        if (errno != EINTR) {
			ResetBit();
			E->Quit("Parent failed whilst waiting for child\n");
            break;
            }
        }
		//----------------------------------------------------------------------------	
		//			Restore the original signal handlers
		//----------------------------------------------------------------------------	
        if (sigaction(SIGINT,&SaveInt,NULL)<0) {
			ResetBit();
			E->Quit("Unable to restore SIGINT handler\n");
            }
        if (sigaction(SIGQUIT,&SaveInt,NULL)<0) {
			ResetBit();
			E->Quit("Unable to restore SIGQUIT handler!\n");
            }
        if (sigprocmask(SIG_SETMASK,&SaveMask,NULL)<0) {
			ResetBit();
			E->Quit("Unable to restore Sigprocmask!\n");
        }
		
return status;
}

} // edm namespace ends
