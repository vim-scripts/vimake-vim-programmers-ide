// =====================================================================================
// 
//       Filename:  vcnfg.cc
// 
//    Description:  Source code to change the Make(build) configuration during a
//    				Vim - Gvim session. (part of the vimake package)
// 
//         $Id: vcnfg.cc,v 1.8 2011/02/23 11:23:15 mike Exp $
//         $Revision: 1.8 $
// 
//         Author:  Mike Lear, statusofthenight2003@yahoo.com
//	                                                                          
//	 Copyright (C) 2006-10 Mike Lear <statusofthenight2003@yahoo.com>            
//	                                                                          
//	 This file is free software; as a special exception the author gives      
//	 unlimited permission to copy and/or distribute it, with or without       
//	 modifications, as long as this notice is preserved.                      
//	                                                                          
//	 This program is distributed in the hope that it will be useful, but      
//	 WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//	 implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//	 
// =====================================================================================

#include "vcnfg.h"
namespace edm {
using       namespace edn;



// =====================================================================================
//       Class:   VICONFIG
//	    Method:	  GetViPath get path to users vimake configuration files
//                Returns  path with file suffix appended
// =====================================================================================
auto_ptr <string> Viconfig::GetViPath(const char* InFileName) {
Error <string> E;

				struct passwd *pw;
		if (!(pw = getpwuid(getuid())))
				E->Quit("Unable to obtain user's home directory.\n");
	
			auto_ptr <string>	ViMakePath (new string(InFileName));
		if (ViMakePath -> size() == 0) E->Quit("Bad command\n");
				std::string::size_type idx;
				idx = ViMakePath -> rfind('.');

		if (idx == string::npos) 
				throw FilePathError(InFileName);
			auto_ptr<string> FileExtent (new string);
			FileExtent -> assign (*ViMakePath,idx+1,ViMakePath ->size());

			idx = GetFileExt(*FileExtent);

		if (idx == 3) {		
			long status = Strstr(*ViMakePath);
			status &= 24;   

		switch (status) {
			case 8:		*FileExtent="asm";   
						break;
			case 16:   *FileExtent="s";     
						break;
	   		default:	break;
				 }
			 }

				*ViMakePath =  pw->pw_dir;
				*ViMakePath += "/etc/" + *FileExtent;

return ViMakePath;
}



// =====================================================================================
//       Class:   VICONFIG
//      Method:   GETSETCFG ( Get and Set build configuration)
//				  Create a menu allowing the user to choose a configuration
// =====================================================================================
int Viconfig::GetSetCfg(std::string& InFileName) {
Error <string>E;	
struct stat statbuf;

			auto_ptr < string > CmdName  (new string("/etc/cmdline.arg"));
			auto_ptr < string > TmpString (Getenv("HOME"));
			CmdName -> insert (0, *TmpString);  // get path to cmdline.arg
			ifstream fin;
			fin.open(CmdName->c_str());
		if (!fin) throw FilePathError(CmdName->c_str());	

			auto_ptr < string > bitstr (new string);
			fin >> *bitstr;
			fin.close();

			std::bitset<Keys> FunKey (string(bitstr->c_str()));

				std::string::size_type idx;
				idx = InFileName.rfind('/');
				auto_ptr<string> ext(new string(InFileName.substr(++idx,3)));

		if (idx == string::npos) {
				throw FilePathError(InFileName);
		}

				auto_ptr<string>   suffix(new string("lua"));
				suffix -> assign(InFileName,idx,InFileName.size());

		if  (suffix -> compare (0,idx,"lua",0,idx) == 0)
			{ 			// Luac FOUND
				_Options.insert(0,InFileName);
				
		if (stat(_Options.c_str(),   &statbuf)<0)
				E->Quit("Not a vimake configuration file!\n");

		if (isXterm == true) { 
				cout << nTab << Blue << "LUAC COMPILER-OPTIONS" << Off << endl;

		} else {  
				cout <<  "\tLUAC COMPILER-OPTIONS\n";
				}
				MapToFile(_Options);

		} else {  	// C,CPP,ASM  FOUND 			

				idx = GetFileExt(*ext);  // find out source file type
		if (idx == string::npos) 
				throw FilePathError(InFileName);
		 
		if (idx != 3) FunKey.reset(F6); // Reset F6 if source file is not assembly
				_Options.insert(0,InFileName);

		if (FunKey.test(F6)) { 			// if in auto asm mode use either asm_options or s_options
				idx = InFileName.rfind('/');

		if (idx != string::npos){
			auto_ptr<string> Tmp(new string(InFileName.substr(0,++idx)));
				Tmp->append("a_libraries");
				_Libraries = *Tmp;		// for auto mode switch to a_libraries
			} else {
				throw FilePathError(InFileName.c_str());
				}
			} else {	
				_Libraries.insert(0,InFileName);  // all other souurce libraries 
				}

		if (stat(_Libraries.c_str(), &statbuf)<0) 
				E->Quit("Not a vimake configuration file!\n");

		if (stat(_Options.c_str(),   &statbuf)<0)
				E->Quit("Not a vimake configuration file!\n");
				cout << nTab << "COMPILER-ASSEMBLER OPTIONS\n";
				MapToFile(_Options);
				cout << nTab << "LINK OPTIONS\n";
				MapToFile(_Libraries);
				sleep(2);
				}

return 0;
}


// =====================================================================================
//       Class:   VICONFIG
//      Method:   MapToFile  (Modify the position of configuration in a file using a Map)
// =====================================================================================
void Viconfig::MapToFile(std::string& InFileName) {
Error <string>E;	

			//----------------------------------------------------------------------
			//  Option menu for Vim or Gvim 
			//----------------------------------------------------------------------
			extern bool isXterm;
			auto_ptr<string>FirstLine (new string);
		if (isXterm == true) { 
			FirstLine -> append ("\e[34mWhere option 1 is NO CHANGE\e[0m\n");

		} else {  
			FirstLine -> append ("Where option 1 is NO CHANGE\n");
			}

			auto_ptr<string> OutFileName (new string("/tmp/vim.XXXXXX"));
		if  (mkstemp((char*)OutFileName->c_str())<0)
				throw FileOpenError(OutFileName->c_str());

			std::ofstream fout; 
			fout.open(OutFileName -> c_str(), std::ios_base::out|std::ios_base::app);

		if (!fout.is_open()) throw FileWriteError(OutFileName -> c_str());

				std::ifstream fin;
				fin.open(InFileName.c_str(), std::ios_base::in);
		if (!fin.is_open())	E->Quit("Unable to open ",InFileName.c_str()," for reading.\n");

			unsigned int Selected, Position = 0;
			Selected = Position;
			std::map<int,std::string> vimap;             
			auto_ptr<string> InFileLine (new string);

   		while (fin) {  // skip over comments and newlines
    		if ((fin.peek() == '#')||(fin.peek() == '\n')) {
		 	getline(fin, *InFileLine, '\n');
			fout << *InFileLine << endl;  // write to temp file
			fout.flush();
			InFileLine->clear();
        		continue;
        		}

		 getline(fin, *InFileLine, '\n');
		 if (!fin) break;
			vimap.insert(std::pair<int,std::string>(++Position,*InFileLine)); 
      		}

			if (vimap.size() == 0) {
				E->Mesg(InFileName,"contains no link libraries!\n");
				return;  
				}

			
			/// vimap.erase(vimap.size());
			fin.close();
			fout.close();

			std::map<int,std::string>::iterator itr;
			itr = vimap.begin();


			auto_ptr<string> FirstMapLine (new string);
			FirstMapLine -> append (itr->second); 								 
			cout << nTab << "Valid options are [ 1 - " << vimap.size()
				 <<	" ] " << FirstLine -> c_str() << endl;
			std::ostringstream ostr;

		for (itr = vimap.begin(); itr != vimap.end(); ++itr){
			isXterm == true ? ostr << Blue << " [" << itr->first << "]\t" << Off : 
							  ostr <<  "\t [" << itr->first << "]\t";
							  ostr << itr->second.c_str();
			if (isXterm == false) ostr << endl;				  
							  }
			cout << ostr.str() << endl;
			cout << "\n\tEnter no: ";

		if (!std::cin.good()) 
			E->Quit("input stream in a bad state\n");

  		while (true){
				std::cin >> Position;

			//----------------------------------------------------------------------
			//  Locate index and set iterator
			//----------------------------------------------------------------------
  		if (std::cin.good()){   
				itr = vimap.find(Position);
				break;

  		} else if 
				(std::cin.eof()){  		
				break; 

  		} else {  						      
				std::cin.clear();   	
				std::string badtoken; 	
				std::cin >> badtoken; 
				E->Quit("Bad input encountered: ",badtoken.c_str());
				}
		}
		//----------------------------------------------------------------------
		//  Use index to save the line selected in the map.
		//  At this point 2 lines from the map have been saved.
		//----------------------------------------------------------------------
		auto_ptr <string>  SecondMapLine(new string);
		if (itr != vimap.end()) { 
				SecondMapLine -> append (itr->second); 
				Selected += itr->first;
		} else {
				E->Quit("Invalid selection!\n");
		}

		//----------------------------------------------------------------------
		//  Erase the selected line in the map, also erase line 1 from the map.
		//  Swap the two saved lines over (strings FirtsMapLine,SecondMapLine)
		//  then insert these two lines back into the map in the erased positions.
		//  Finally write the modified map back to the configuration file.
		//----------------------------------------------------------------------
			vimap.erase(1); 			 		
			vimap.erase(Selected);       		    
			FirstMapLine -> swap(*SecondMapLine); 	
			vimap.insert(std::pair<int,std::string>(1,*FirstMapLine)); 
			vimap.insert(std::pair<int,std::string>(Selected,*SecondMapLine)); 
			fout.open(OutFileName -> c_str(), std::ios_base::out|std::ios_base::app);

		if (!fout.is_open()) throw FileWriteError(OutFileName -> c_str());

		for (itr = vimap.begin(); itr != vimap.end(); ++itr) {
			fout  << itr->second << std::endl; 
			}
			fout.close();
			
		if	(rename(OutFileName -> c_str(),InFileName.c_str())<0) {
			E->Quit("Unable to rename temp file to ",InFileName.c_str(),"\n");
			}


			vector<unsigned int> usize;
			usize.push_back(FirstMapLine -> size());
			usize.push_back(SecondMapLine -> size());
			std::vector<unsigned int>::iterator lineBreak;
			lineBreak  = max_element(usize.begin(),usize.end());
			cout << nTab << "+";
		for (unsigned int a = 0; a < (*lineBreak) + 10; a += 2) {
			cout << "-+";
			}
		if (isXterm == true) { 
			cout << HiGreen << "Selected:   " << Off <<  *FirstMapLine;
			cout << Red     << "Deselected: " << Off <<  *SecondMapLine;
		} else {
			cout <<  "\n\tDeselected: "  <<  *SecondMapLine;
			cout <<  "\n\tSelected:   "  <<  *FirstMapLine;
			}
			cout << nTab << "+";
		for (unsigned int a = 0; a < (*lineBreak) + 10; a += 2) {
			cout << "-+";
			}
			cout << endl;
	}

} // namespace ends

