// =====================================================================================
// 
//       Filename:  vclean.cc
// 
//    Description:  Remove object and executable files from current directory
// 
//         $Id: vclean.cc,v 1.10 2011/03/10 22:59:19 mike Exp $
//         $Revision: 1.10 $
// 
//         Author:  Mike Lear (motn), mikeofthenight2003@yahoo.com
//		   Copyright (C) 2006-9 Mike Lear <mikeofthenight2003@yahoo.com>            
//	                                                                          
//		   This file is free software; as a special exception the author gives      
//	 	   unlimited permission to copy and/or distribute it, with or without       
//		   modifications, as long as this notice is preserved.                      
//	                                                                          
//	 	   This program is distributed in the hope that it will be useful, but      
//	 	   WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//	  	   implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// =====================================================================================

#include "vclean.h"
extern char **environ;
namespace edm {
using namespace edn;


//--------------------------------------------------------------------------------------
//       Class:  VCLEAN
//      Method:  CONSTRUCTOR
// Description:  Parameter Initialization
//--------------------------------------------------------------------------------------
Vclean::Vclean(std::string &InMainFileName) {

std::string::size_type idx;
std::string FileNameExt;

                _DisplayMode  = 0;
                _MainFileSrc = InMainFileName;
                _MainFileExe  = InMainFileName;
                idx           = InMainFileName.rfind('.');

            if (idx == std::string::npos) {
                throw FileIndexError(InMainFileName);

            } else {
                FileNameExt.assign(_MainFileSrc,idx,_MainFileSrc.size());
                _MainFileExe.erase (idx, FileNameExt.size ());
                }
}

//--------------------------------------------------------------------------------------
//       Class:  VCLEAN
//      Method:  VALIDITY
// Description:  This version of Validity allows the removal of object and
//               executable files only if a valid file type has been loaded
//               whilst in a vimake session. 
//               This is to make it more difficult to remove executable and 
//               object files directly from the command line, although this
//               is not foolproof.
//--------------------------------------------------------------------------------------
int Vclean::Validity(const string& InFileName) {

string      FileExtent;
string      FileName;
string::size_type index;

                FileName = InFileName;
                index    = FileName.rfind('.');
                FileExtent.assign(FileName,++index,FileName.size());
                index    = GetFileExt(FileExtent);
        switch (index) {
            case 1:         // return only known file extension types.
            case 2:         // throw an error for all others.
            case 3:
            case 4:
            case 6:     break;
            default:    throw FileUnknownError(FileName.c_str());
                        break;
            }


return index;
}


//--------------------------------------------------------------------------------------
//       Class:  VCLEAN
//       Member: DisplayObj
// Description:  Display all object and executable files from current working directory
// 				 Uses the template below to format the output into  a number of columns.
// 				 Determined by the window size. Obtains the width from the kernel.
// 				 Default is two columns should an error occur obtaining window width.
//--------------------------------------------------------------------------------------
//  The winsize structure contains the following members
//    			unsigned short ws_row;
//        		unsigned short ws_col;
//            	unsigned short ws_xpixel;
//              unsigned short ws_ypixel;
//--------------------------------------------------------------------------------------
//


unsigned short WinWidth(void) {
bool isXterm;
auto_ptr<string> TermType (new string(getenv("TERM")));

			*TermType == "xterm" ? isXterm = true : isXterm = false;
		if (isXterm == false) {
			unsigned short x = 100;  // default size for dumb terminal
			return x;
			}

	struct winsize size;

	if (ioctl(0,TIOCGWINSZ,(char*) &size)<0)
		throw RunTimeError("TIOCGWINSZ error");
		unsigned short x = size.ws_col;
return x;
}

template <typename T>
void ShowFileNames(const std::string& msg,T start, T end){
int WinWidth(void);
int i=0;
T itr;
const  int columns = 20;
int 		   col = WinWidth(); // get current screen width from kernel
			
			col = col/columns;
		if (col <= 1) (col = 2);
            cout.setf(ios::left,ios::adjustfield);
            cout << msg.c_str() << endl;
			cout << "";
        for (itr = start; itr != end; ++itr,++i){
        if (i == 1) {
            cout << "";
            cout.width(columns);
            cout.fill(' ');
            cout << *itr << "";
        } else if (i == col ) {
            i=0;
            cout << "";
            cout.width(columns);
            cout << *itr << "" << endl;
        } else if (i== 0){
            cout  <<  "";
		} else {	
            cout.width(columns);
            cout  << *itr << "";
            }
        }
        cout << endl;

}

template <typename T>  // Remove contents of stl container 
void Removeit(const std::string& msg,T start, T end){
		T itr;
		std::cerr << msg.c_str() << std::endl;
		for (itr = start; itr != end; ++itr) {
		if (unlink((char*)itr->c_str())== 0){	// remove executable files
			std::cerr << "\tRemoving " << *itr << std::endl;
			}
		}
		std::cerr << std::endl;
	}



void   Vclean::DisplayObj(char choice) {
Error<string> E;
DIR *dp;
struct dirent *direntp;
struct stat statbuf;
list <string> List;
list <string>::iterator itr;

				string::size_type index;
				auto_ptr <string> ext_file (new string);    
                auto_ptr <string> old_file (new string);
				auto_ptr <string> chk_line (new string);
				ifstream fin;

         if ((dp = opendir(".")) == NULL) 			// run in the current working directory
			 throw FileDirError();
            
					/// List.insert(List.end(),*old_file);
             while ((direntp = readdir(dp)) != NULL) {

                if (direntp->d_ino == 0)			// skip over removed files (inode = 0)
                    continue;

                if (stat(direntp->d_name,&statbuf) <0) {
                    E->Mesg("Cannot get information on",direntp->d_name,"\n");
                    }
					*old_file = direntp->d_name;
					index = old_file -> find(".o");
					
				if (index != string::npos) {
					*ext_file = old_file -> substr(index+1);
				
				if (ext_file -> size() == 1){
					List.insert(List.end(),*old_file);
					}
				}
					*old_file = direntp->d_name;
					index = old_file -> find(".d");

				if (index != string::npos) {
					*ext_file = old_file -> substr(index+1);

				if (ext_file -> size() == 1){
					List.insert(List.end(),*old_file);
					}
				}


                if (statbuf.st_mode &  S_IFDIR)		// skip over any directories
                    continue;

					index = 0;

                if (statbuf.st_mode &  S_IXUSR) {  // BUG FIX: 
					*old_file = direntp->d_name;   
					fin.open(old_file->c_str(),std::ios::in);

				 if (fin.fail()) { continue;} else {
					getline(fin,*chk_line);
					fin.clear();
					fin.close();
					index = chk_line->find("#!/");

				if (index != string::npos) {	
					continue;
					} 
					*old_file = direntp->d_name;   
					List.insert(List.end(),*old_file);
					}
				}				        
			}
			List.sort();
			if (choice == 'y') {
			Removeit("\nFiles being removed from current directory:",List.begin(),List.end());
			/// sleep(5);
			} else {
			ShowFileNames("\nFiles selected for removal, but NOT removed:",List.begin(),List.end()); 
			/// sleep(5);
			}

closedir(dp);
}

} // namespace edm
