#ifndef __VMAKE__H
#define __VMAKE__H
// =====================================================================================
// 
//       Filename:  vmake.h
// 
//    Description:  Header File for the Vkeys class
// 
//          $Id: vmake.h,v 1.9 2011/02/22 19:08:09 mike Exp $
//          $Revision: 1.9 $
// 
//         Author:  Mike Lear (motn), mikeofthenight2003@yahoo.com
//	 Copyright (C) 2006-10 Mike Lear <mikeofthenight2003@yahoo.com>           
//	                                                                          
//	 This file is free software; as a special exception the author gives      
//	 unlimited permission to copy and/or distribute it, with or without       
//	 modifications, as long as this notice is preserved.                      
//	                                                                          
//	 This program is distributed in the hope that it will be useful, but      
//	 WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//	 implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// 
// =====================================================================================


//----------------------------------------------------------------------
//   	Header and Namespace declarations.
//----------------------------------------------------------------------
#include 	<iostream>
#include 	<fstream>
#include 	<sstream>
#include 	<string>
#include 	<list>
#include 	<map>
#include 	<memory>
#include 	<vector>
#include 	<algorithm>
#include 	<sys/stat.h>
#include 	<sys/wait.h>
#include 	<pwd.h>
#include 	<utime.h>
#include  	"utils.h"



namespace 	edn {

using 	std::cout;
using 	std::cerr;
using	std::cin;
using 	std::endl;
using 	std::ends; 	
using 	std::ifstream; 
using 	std::ofstream; 
using 	std::hex;
using 	std::dec;
using 	std::string; 	
using 	std::list;
using 	std::vector;
using 	std::istringstream;
using 	std::ostringstream;
using 	std::stringstream;
}


namespace 	edm{
extern bool isXterm;	
using 	namespace edn;

				template <class Any>
				void Swap(Any &a,Any &b) {
					Any temp;
					temp = a;
					a = b;
					b = temp;
					}


//----------------------------------------------------------------------
// 		Offsets into a vector of 12 strings
//----------------------------------------------------------------------
const 	unsigned HeaderFileList   = 0;
const 	unsigned SourceFileList   = 1;
const 	unsigned ObjectFileList   = 2;
const 	unsigned AssemblyFileList = 3;
const 	unsigned TemporaryObject  = 4;
const 	unsigned IncludeFileList  = 5;
const 	unsigned HeaderFileName   = 6;
const 	unsigned ObjectFileName   = 7;
const 	unsigned SourceFileName   = 8;
const 	unsigned TempFileExtent   = 9;
const 	unsigned CppTempObjList   = 10;
const 	unsigned AsmTempObjList   = 11;



const string MainFile("main.m");
const string CppMainFile("main.cc");

// =====================================================================================
//  	  Class:	Auto
//  Description:	A class to automate the selection of the Gas(as) and Nasm assemblers
//  	Returns:	A string containing the relevant assembly command and a long value
//  				which determines which assembler to use.
// =====================================================================================
    class Auto {
        private:
            string name;
            long number;
        public:
            Auto() { name  = ""; number = 0; } // Default constructor. 
            Auto(string n, long num) {
                name = n;                      // Construct a complete Auto object. 
                number = num;
                }

            string get_name() { return name; } // Accessor functions for Auto data. 
            long get_number() { return number; }
        };



// =====================================================================================
//        Class:  Vkeys
//  Description:  A class of utility methods to  manage multi language assembly,compiling
//  			  and linking.
// =====================================================================================
	class Vkeys : public virtual Utils, public Auto  {  
		private:
			string 	_Libraries;
			string	_Options;		
			string 	_BuildFile; 	
			string::size_type _Index;
		protected:
			string	_MainFileSrc;   	
			string	_MainFileObj;   	
			string	_MainFileExe;
			string  _MainFileHdr;
			struct  stat MainFileBuffer, MainObjBuffer, MainExeBuffer;
		public:
			Vkeys(string &str);
			virtual void SetProgName(const string& str);
			virtual ~Vkeys() {};
			virtual auto_ptr < string > Bcompile(string &str);   
			virtual auto_ptr <string> NewName(const string& InFileName,unsigned Index);
			virtual auto_ptr <string> GetLinker(string &InFile);
			virtual int BuildMainFile(const string &str);
			virtual int BuildMainFile(void);
			virtual int BuildLuaBin(const string& str);
  			virtual int Blink (string &str);
			virtual int Argcount();
			virtual int Makefile(string &str); 
			virtual auto_ptr<string> Lastargs ( const std::string &InCommandLine);
			virtual bool CheckFileTimes(const string &st1,const string &st2); 
			Vkeys *operator->() { return this; };
	};

}
#endif

