#import "SysInf.h"


@implementation SysInformation

-(void) usingVimake {

    currentTime = time( NULL );
    tm_time = localtime( &currentTime );
    status = sysinfo( &info );

  if (status == 0) {
    if ((ptr = malloc(MEM_SIZE)) ==  NULL) {
        fprintf(stderr,"memory stack error\n");
        exit(1);
        }

    if ((shmid = shmget(IPC_PRIVATE,SHM_SIZE,SHM_MODE)) < 0) {
        fprintf(stderr,"Shared memory get error\n");
        exit(1);
        }

    if ((shmptr = shmat(shmid,0,0)) == (void *) -1) {
        fprintf(stderr,"Shared attached memory error\n");
        exit(1);
        }

    if (shmctl(shmid,IPC_RMID,0) <0) {
        fprintf(stderr,"Shared control error\n");
        exit(1);
        }
			now  = info.uptime;
			days = info.uptime / (24 * 60 * 60);
			info.uptime -= (days * (24 * 60 * 60));
			hours = info.uptime / (60 * 60);
			info.uptime -= (hours * (60 * 60));
			minutes = info.uptime / 60;
			info.uptime -= (minutes * 60);
			seconds = info.uptime;

		NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
		NSString *Str1  =  @"System Information:";
		NSString *Str2  = [NSString stringWithFormat: @"\n\tCurrent time                %s",  asctime( tm_time )];
		NSString *Str3  = [NSString stringWithFormat: @"\tUptime is %ld seconds,", now ];
		NSString *Str4  = [NSString stringWithFormat: @" %d Days %d Hours %d Minutes %d Seconds",days,hours,minutes,seconds];
		NSString *Str5  = [NSString stringWithFormat: @"\n\tOne minute load average     %ld", info.loads[0] ];
		NSString *Str6  = [NSString stringWithFormat: @"\n\tFive minute load average    %ld", info.loads[1] ];
		NSString *Str7  = [NSString stringWithFormat: @"\n\tFifteen minute load average %ld", info.loads[2] ];
		NSString *Str8  = [NSString stringWithFormat: @"\n\tTotal Ram Available         %ld", info.totalram ];
		NSString *Str9  = [NSString stringWithFormat: @"\n\tFree Ram Available          %ld", info.freeram ];
		NSString *Str10 = [NSString stringWithFormat: @"\n\tShared Ram Available        %ld", info.sharedram ];
		NSString *Str11 = [NSString stringWithFormat: @"\n\tBuffer Ram Available        %ld", info.bufferram ];
		NSString *Str12 = [NSString stringWithFormat: @"\n\tTotal Swap Size             %ld", info.totalswap ];
		NSString *Str13 = [NSString stringWithFormat: @"\n\tAvailable Swap Size         %ld", info.freeswap ];
		NSString *Str14 = [NSString stringWithFormat: @"\n\tProcesses running:          %d", info.procs ];
		NSString *Str15 = [NSString stringWithFormat: @"\n\tTotal high memory size      %ld", info.totalhigh ];
		NSString *Str16 = [NSString stringWithFormat: @"\n\tTotal high memory size      %ld", info.totalhigh ];
		NSString *Str17 = [NSString stringWithFormat: @"\n\tAvailable high memory       %ld", info.freehigh ];
		NSString *Str18 = [NSString stringWithFormat: @"\n\tMemory Unit size            %d", info.mem_unit ];
		NSString *Str19 = [NSString stringWithFormat: @"\n\tBSS: unitialized data from  0x0%lx to 0x0%lx",
							(unsigned long)&array[0],(unsigned long)&array[ARRAY_SIZE] ];
		NSString *Str20 = [NSString stringWithFormat: @"\n\tStack is around             0x%lx",(unsigned long)&shmid ];
		NSString *Str21 = [NSString stringWithFormat: @"\n\tHeap is from                0x0%lx to 0x0%lx",
							(unsigned long)ptr,(unsigned long)ptr+MEM_SIZE ];
		NSString *Str22 = [NSString stringWithFormat: @"\n\tShared memory attached from 0x%lx to 0x%lx",
							(unsigned long)shmptr,(unsigned long)shmptr+SHM_SIZE ];
	

		printf( "%s", [Str1 cString ]);  	printf( "%s", [Str2 cString ]);  	printf( "%s", [Str3 cString ]);
		printf( "%s", [Str4 cString ]);  	printf( "%s", [Str5 cString ]);  	printf( "%s", [Str6 cString ]);
		printf( "%s", [Str7 cString ]);  	printf( "%s", [Str8 cString ]);  	printf( "%s", [Str9 cString ]);
		printf( "%s", [Str10 cString]);  	printf( "%s", [Str11 cString]);  	printf( "%s", [Str12 cString]);
		printf( "%s", [Str13 cString]);  	printf( "%s", [Str14 cString]);  	printf( "%s", [Str15 cString]);
		printf( "%s", [Str16 cString]);  	printf( "%s", [Str17 cString]);  	printf( "%s", [Str18 cString]);
		printf( "%s", [Str19 cString]);  	printf( "%s", [Str20 cString]);  	printf( "%s", [Str21 cString]);
		printf( "%s", [Str22 cString]);

		[pool release];

    } else {

		fprintf(stderr,"Error obtaining system information\n");
	exit(1);
	}


}
@end

