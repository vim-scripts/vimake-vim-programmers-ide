#import "SysInf.h"

/*
   Build with SysInf.m SysXtra.m SysInf.h

      Vimake with objective-C demonstration program
      See the Tutorial for build instructions 
 			Author: Mike Lear

    This program has been written to specifically demonstrate Vimake & Objective-C
	It could have be written far more concisely, but I decided to split the program
	up over several files and use objective-c print routines which could have easily
	been replaced with standard C print routines.
	But this is only a demonstration program and not a finished production program.

 */

int main( int argc, const char *argv[] ) {
	
    SysInformation *obj  = [[SysInformation alloc] init];
    SystemInfo     *obj1 = [[SystemInfo     alloc] init];

    [obj  usingVimake ];
    [obj1 usingObjectC];

    [obj  release];
    [obj1 release];

return 0;
}
